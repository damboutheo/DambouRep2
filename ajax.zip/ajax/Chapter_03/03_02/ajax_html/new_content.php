<?php
$var = 'new content';
// echo $var;
// return;
 ?>
<span style="color:blue;">This is the <strong><?php echo $var;?> </strong>  which has been loaded by Ajax.</span>
