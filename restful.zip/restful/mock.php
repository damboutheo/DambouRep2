<?php
require 'vendor/autoload.php';
use GuzzleHttp\Client;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\Psr7\Response;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Exception\ClientException;

$mock = new MockHandler([
    new Response(200),
    new Response(200, ['-FOO' => 'test']),
    new ClientException('Error', new Rquest('GET', 'test')),
]);

$handler = HandlerStack::create($mock);
$client = new Client(['handler'=> $handler]);

echo $client->request('GET', '/')->getStatusCode() . "\r\n";
var_dump($client->request('GET', '/')->getHeader('-Foo'));
echo $client->request('GET', '/')->getStatusCode() . "\r\n";