<?php
require 'vendor/autoload.php';
use GuzzleHttp\Psr7\request;

$request = new Request('GET', 'http://jsonplaceholder.typicode.com/posts/1');

echo $request->getURI() . "\r\n";
echo $request->getURI()->getScheme() . "\r\n";
echo $request->getURI()->getPort() . "\r\n";
echo $request->getURI()->getHost() . "\r\n";
echo $request->getURI()->getPath() . "\r\n";
