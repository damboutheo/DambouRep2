<?php
require("database.php");

// POST
//get
//PUT
//delete
//Handles post request
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_GET["id"]) && $_POST["_method"] == "PUT") {
  $title = $_POST["title"];
  $langue = $_POST["langue"];
  $date_mes = $_POST["date_mes"];
  $description = $_POST["description"];
  $id = $_GET["id"];
  try {
    $statement = $pdo->prepare(
      'UPDATE message SET title = :title, language = :langue, Date_of_the_day = :date_mes, description= :description, WHERE id = :id'

    );
    $statement->execute(["title" => $title, "langue" => $langue, "date_mes" => $date_mes, "description"=>$description, "id" => $id]);
    echo "Data updated";
  } catch (PDOException $e) {
      echo "<h4 style='color: red;'>".$e->getMessage(). "</h4>";
  }

}
//Handles get request
if (isset($_GET["id"])) {
  $id = $_GET["id"];
  try {
    $statement = $pdo->prepare(
      'SELECT * FROM message WHERE id = :id;'
    );
    $statement->execute(["id" => $id]);
    $results = $statement->fetchAll(PDO::FETCH_OBJ);
  } catch (PDOException $e) {
      echo "<h4 style='color: red;'>".$e->getMessage(). "</h4>";
  }
}
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Devotional</title>
  </head>
  <body>
      <form class="updating" action="update.php?id=<?php echo $results[0]->id;?>" method="POST">
          <input type="hidden" name="_method" value="PUT">
            <label for="title">Title</label><br>
            <input type="text" name="Title" value="<?php echo
            $results[0]->title;?>"><br>
            <label for="langue">language</label><br>
            <input type="text" name="language" value="<?php echo
            $results[0]->langue;?>"><br>
            <label for="date_mes">Date</label><br>
            <input type="date" name="date_mes" value="<?php echo
            $results[0]->date_mes;?>"><br>
            <label for="description">Description</label><br>
            <input type="textarea" name="description" value="<?php echo
            $results[0]->description;?>"><br>
            <button type="Submit" name="Save">Save</button>

      </form>
      <a href="read.php?show=all">Go back</a>

  </body>
</html>
