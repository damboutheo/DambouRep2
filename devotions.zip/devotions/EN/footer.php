<!DOCTYPE HTML>
<html>
<head>
<title>
</title>
</head>
<body>
    
    <div class="footer_inner">
		<div class="footer_in_inner">
		
<div class="social_wrap">
	<div class="social_wrap_inner">
		<ul>
			<li>
				<a href="https://www.facebook.com/GospelOfChristMinistries/?fref=ts" class="cmsmasters_social_icon cmsmasters_social_icon_1 cmsmasters-icon-facebook" title="Facebook" target="_blank"></a>
			</li>
			<li>
				<a href="https://www.youtube.com/user/GCM1207" class="cmsmasters_social_icon cmsmasters_social_icon_2 cmsmasters-icon-youtube" title="" target="_blank"></a>
			</li>
			<li>
				<a href="https://twitter.com/gospelchristmin?lang=fr" class="cmsmasters_social_icon cmsmasters_social_icon_3 cmsmasters-icon-twitter" title="" target="_blank"></a>
			</li>
			<li>
				<a href="http://www.instagram.com/GCM_MEDIAHOUSE" class="cmsmasters_social_icon cmsmasters_social_icon_4 cmsmasters-icon-instagram" title="" target="_blank"></a>
			</li>
			<li>
				<a href="#" class="cmsmasters_social_icon cmsmasters_social_icon_5 cmsmasters-icon-gplus" title="Google" target="_blank"></a>
			</li>
		</ul>
	</div>
</div>			<span class="footer_copyright copyright">© 2016 Gospel of Christ Ministries</span>
		</div>
	</div>
</body>
</html>



<div style="display: flex; white-space: nowrap; overflow-x: auto; overflow-y: hidden; word-break: break-word; align-items: center; justify-content: center;">
		<a href="https://twitter.com/LeSiteduDev" target="_blank" class="social-cust social-cust-tw">
			<i class="fab fa-twitter"></i>
		</a>
		<a href="https://www.youtube.com/channel/UCmJ6Z6gXjjylSVbPoBvj-ow" target="_blank" class="social-cust social-cust-yb">
			<i class="fab fa-youtube"></i>
		</a>
		<a href="https://www.facebook.com/sitedudev/" target="_blank" class="social-cust social-cust-fb">
			<i class="fab fa-facebook"></i>
		</a>
		<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
			<input type="hidden" name="cmd" value="_s-xclick">
			<input type="hidden" name="hosted_button_id" value="RZ7KHWFLTGKCL">
			<button type="submit" border="0" name="submit" title="PayPal - The safer, easier way to pay online!" class="social-cust social-cust-tw">
				<i class="fab fa-paypal"></i>
			</button>
		</form>
		<a href="https://discord.gg/mmrw3HK" target="_blank" class="social-cust social-cust-dc">
			<i class="fab fa-discord"></i>
		</a>
	</div>
	<div style="margin-top: 15px; color: #778ca3">
				
		4 visiteurs - 1 en ligne 
	</div>
	<div style="margin-top: 15px; color: #778ca3">
		© 2020 Sitedudev 
		• <a style="color: #778ca3" href="https://www.sitedudev.com/a-propos"><i class="fas fa-info-circle"></i> À propos</a> 
		• <a style="color: #778ca3" href="https://www.sitedudev.com/contact"><i class="fas fa-envelope"></i> Me contacter</a>
		• <a style="color: #778ca3" href="https://www.sitedudev.com/cgu"><i class="fab fa-bandcamp"></i> CGU</a>
		• <a style="color: #778ca3" href="https://www.sitedudev.com/maj"><i class="fas fa-broadcast-tower"></i> MAJ</a>
	</div>

		