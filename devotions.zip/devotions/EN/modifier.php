<?php
session_start();
include_once('includes.php');

if(!isset($_SESSION['pseudo'])){
	header('Location: accueil.php');
	exit;
}

if(!empty($_POST)){
	extract($_POST);
	$valid = true;

	if($modifier == "form"){
		$Pseudo = htmlspecialchars(trim($Pseudo));
	
		if(empty($Pseudo)){
			$valid = false;
			$_SESSION['flash']['danger'] = "Please enter your username !";
			
		}
		
		$req = $DB->query("Select pseudo from user where idpublic = :id", array('id' => $_SESSION['id']));
		$req = $req->fetch();
		
		if($Pseudo == $_SESSION['pseudo']){
			$valid = false;
			$_SESSION['flash']['info'] = "Your username is the same";
		
		}
		
		if($valid){
			
			$DB->insert("UPDATE user SET pseudo = :newpseudo where idpublic = :id ", array('id' => $_SESSION['id'], 'newpseudo' => $Pseudo));
			
			$_SESSION['pseudo'] = $Pseudo;
			$_SESSION['flash']['success'] = "Your username has been edited !";
			header('Location: modifier.php');
			exit;
		}
		
	}elseif($modifier == "mdp"){
		
		$Password = trim($Password);
		$PasswordConfirmation =trim($PasswordConfirmation);
		$NewPassword = trim($NewPassword);
		
		$req = $DB->query("Select * from user where idpublic = :id", array('id' => $_SESSION['id']));
		$req = $req->fetch();
		
		if(empty($Password)){
			$valid = false;
			$_SESSION['flash']['warning'] = "Please enter your password !";
		
		}elseif($Password && empty($PasswordConfirmation)){
			$valid = false;
			$_SESSION['flash']['warning'] = "Please confirm your password";

		}elseif($Password != $PasswordConfirmation){
			$valid = false;
			$_SESSION['flash']['danger'] = "Your password does not match the password !";

		}else if($req['password'] != (crypt($Password, '$2a$10$1qAz2wSx3eDc4rFv5tGb5t'))){
			$valid = false;
			$_SESSION['flash']['danger'] = "Your password is not the right one !";
			
		}else if(empty($NewPassword)){
			$valid = false;
			$_SESSION['flash']['warning'] = "Please enter a new password !";
	
		}else if($valid){
			
			$DB->insert("UPDATE user SET password = :newpassword where idpublic = :id", array('id' => $_SESSION['id'], 'newpassword' => (crypt($NewPassword, '$2a$10$1qAz2wSx3eDc4rFv5tGb5t'))));
			
			$_SESSION['flash']['success'] = "Your new password has benn saved !";
			header('Location: modifier.php');
			exit;
			
		}	
	}
}		
?>
<!DOCTYPE html>
<html lang="fr">
	<header>
		
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
		<link href="bootstrap/js/bootstrap.js" rel="stylesheet" type="text/css"/>
		
		<link href="style.css" rel="stylesheet" type="text/css" media="screen"/>
		
		<title>Edit profile</title>
	</header>
	
	<body>	
		
		<?php 
		    if(isset($_SESSION['flash'])){ 
		        foreach($_SESSION['flash'] as $type => $message): ?>
				<div id="alert" class="alert alert-<?= $type; ?> infoMessage"><a class="close">X</span></a>
					<?= $message; ?>
				</div>	
		    
			<?php
			    endforeach;
			    unset($_SESSION['flash']);
			}
		?> 
			
		
		<div class="container-fluid">
			
	        <div class="row">
		       	
		       	<div class="col-xs-1 col-sm-2 col-md-3"></div>
		       	<div class="col-xs-10 col-sm-8 col-md-6">
			       	
			       <h1 class="index-h1">Edit your profil</h1>
			       	
			       <br/>
	                
	                <form method="post" action="modifier.php">
	                    
                        <label>Username</label>
                        
                    	<input class="input" type="text" name="Pseudo" placeholder="Username" value="<?= $_SESSION['pseudo'];  ?>" maxlength="20" required="required">

						<br/>
						<br/>
						
	                    <div class="row">
	                        <div class="col-xs-0 col-sm-10 col-md-2"></div>
	                        <div class="col-xs-12 col-sm-2 col-md-8">
		                        <input type="hidden" value="form" name="modifier"/>
								<button type="submit">Edit</button>
	                        </div>
	                        <div class="col-xs-0 col-sm-1 col-md-2"></div>                                
	                   </div>
						
	                </form>
	                
	                <br/>
	                <br/>
	                
	                <form method="post" action="modifier.php">

	                    <label>Password</label>	                 

                        <input class="input" type="password" name="Password" value="<?php if(isset($Password)){ echo $Password; }?>" placeholder="Password" required="required"/>
					
						<br/>
	
	                    <label>Confirm your password</label>

                        <input class="input" type="password" name="PasswordConfirmation" value="<?php if(isset($PasswordConfirmation)){ echo $PasswordConfirmation; }?>" placeholder="Password confirmation" required="required"/>
	                    
	                    <br/>
	                    
	                    <label>New password</label>
                        <input class="input" type="password" name="NewPassword" placeholder="New password" required="required"/>
						
						<br/><br/>
						
	                    <div class="row">
	                        <div class="col-xs-0 col-sm-10 col-md-2"></div>
	                        <div class="col-xs-12 col-sm-2 col-md-8">
		                        <input type="hidden" value="mdp" name="modifier"/>
								<button type="submit">Edit</button>
	                        </div>
	                        <div class="col-xs-0 col-sm-1 col-md-2"></div>                                
	                   </div>
	
	                </form>
			       
					<br/>
					<a href="accueil.php">Back Home page</a>

		       	</div>
	            <div class="col-xs-1 col-sm-2 col-md-3"></div>
	        </div>
        </div>
		<script src="bootstrap/js/bootstrap.min.js"></script>
	</body>
</html