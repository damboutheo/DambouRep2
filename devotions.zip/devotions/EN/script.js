// var date = new Date();
// document.body.innerHTML = "<h1>Today is: " + date + "</h1>";
    