<?php
function connectDB(){
  try{
    $database = new PDO('mysql:host=127.0.0.1;dbname=devotion', 'root','');
    $database->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   // echo "<h4 style='color: green;'>Connected to database</h4>";
    return $database;
  } catch(PDOException $e){
    echo "<h4 style='color: red;'>".$e->getMessage(). "</h4>";
  }
}
$pdo = connectDB();
function initMigration($pdo){
  try{
    $statement = $pdo->prepare(
      'CREATE TABLE IF NOT EXISTS message (
        id int NOT NULL AUTO_INCREMENT primary key,
        title varchar(255) NOT NULL,
        langue varchar(20),
        date_mes DateTime NOT NULL,
        description LONGTEXT NOT NULL,
        reference LONGTEXT NOT NULL,
        penseedujour LONGTEXT NOT NULL,
        confession LONGTEXT NOT NULL
      );'
    );
    $statement->execute();
  }catch(PDOException $e){
    echo "<h4 style:'color: red;'>".$e->getMessage(). "</h4>";
  }
}
 ?>
