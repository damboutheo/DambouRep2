<?php
require("database.php");
//Create new Users
include("reads.php");
 if (isset($_GET["show"]) && isset($_GET["langue"])) {
    $langue = $_GET["langue"];
    // $date = $_GET["date_mes"];
    try{
      $statement = $pdo->prepare(
        'SELECT * FROM message WHERE langue = :langue;'
      );
      $statement->execute(["langue" => $langue]);

      $results = $statement->fetchAll(PDO::FETCH_OBJ);
    //  echo "Read from table users</br>";
    }catch (PDOException $e) {
        echo "<h4 style='color: red;'>".$e->getMessage(). "</h4>";
}
} else {
   echo "<script>location.href='reads.php?show=All&langue={$langue}' </script>";
   die();
  }


 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Devotional</title>
  </head>
  <body>
  <?php
       include("includes/header.php")
    ?>
      <div class="container">     
            <?php foreach ($results as $message) { ?>
        <strong><?php echo $message->title;?><br></strong>
        <?php echo $message->langue;?><br>
        <?php echo $message->date_mes;?><br>
        <p><?php echo $message->description;?></p><br>
        <?php echo $message->reference;?><br>
        <?php echo $message->penseedujour;?><br>
        <?php echo $message->confession;?><br>
        
                  <!-- <td><a href="update.php?id=<?php echo $message->id;?>">edit</a>
                  </td>
                  <td><a href="delete.php?id=<?php echo $message->id;?>" onclick="confirm()">delete</a>
                  </td> -->
              
        
        </div>     
       <?php } ?>

       <a href="/index.php">Go Back</a>
  </body>
</html>
