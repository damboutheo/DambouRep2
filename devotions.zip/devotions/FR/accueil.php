<?php
session_start();
include_once('includes.php');
	// echo $_SESSION['id'];	
?>

<!DOCTYPE html>
<html lang="fr">
	<header>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script src="https://kit.fontawesome.com/32597ef393.js" crossorigin="anonymous"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" media="screen" href="CSS/mains.css" />
		<link href="style.css" rel="stylesheet" type="text/css" media="screen"/>
		<title>Gospel of Christ Ministries</title>
		<style type="text/css">
a {
  color: #fff;
  display: block;
}
</style>
		<nav class="navbar navbar-default">
          <div class="container-fluid">
            
                    <div class="navbar-header">
                        <img class="navbar-brands" src="IMG/Logo.png" alt="Gospel of christ Ministries" >
                    </div>
					<a href="modifier.php" style: color=>Modifier ton profil</a>
			       	
			       	<a href="deconnexion.php">Se deconnecter</a>
           
              
          </div>
        </nav>
	</header>
	
	<body>
		<!-- <img class="navbar-brand" src="IMG/logo.png" alt="Gospel of christ"> -->
		
		<?php 
		    if(isset($_SESSION['flash'])){ 
		        foreach($_SESSION['flash'] as $type => $message): ?>
				<div id="alert" class="alert alert-<?= $type; ?> infoMessage"><a class="close">X</span></a>
					<?= $message; ?>
        </div>
		    
			<?php
			    endforeach;
			    unset($_SESSION['flash']);
			}
		?> 

	
		<div class="container">
				
	        <div class="row">
		       	
		       	
			       	
			       	<h1 class="index-h1"></h1>
			       	
			       	<p>Bonjour <?php 
				       
				    	if(!isset($_SESSION['id'])){
					       echo "Vous n'êtes pas connecté!";
				    	}else{
					    	echo $_SESSION['pseudo'];
				       	
				       	}
				       	?>
				       	
				    </p>
					
								<form action="reads.php" method="GET">
                        <div class="col-sm">
                            <!-- <div class="thumbnail">
								<label for="langue">Select a language</label><br>
								<select name="langue">
								<option value="English">English</option>
								<option value="Français">Français</option>
								</select>
                             </div> -->
                        </div>
                        <div class="col-sm">
                            <div class="thumbnail">
								<label for="date_mes">Choisir une date</label><br>
								<input type="date" name="date_mes" value=<?php echo date('Y-m-d');?>>
                            </div>
                        </div>
                        <div class="col-sm">
                            <div class="thumbnail">
								<a href="reads.php?Show=All&langue<?php echo $message->langue;?>">
								<style>
								button{
									/*margin: 0px 200px 0 200px;*/
								}
								</style>
								<button type="Submit" name="Save" class="submit">LIRE</button>
								</a>
                            </div>    
                        </div>            
			       	<a href="modifier.php">Modifier ton profil</a>
			       	<br/>
			       	<a href="deconnexion.php">Se connecter</a>
                                    </form>
	            
                
	        
        </div>
	</div>
	<div class="footers">
                <div class="copy">© 2020 Gospel of Christ Ministries</div>
                    <div class="social-media">
                          <ul>
                            <li><a href="https://www.facebook.com/GospelOfChristMinistries/?fref=ts" target="_blank"><i class="fab fa-facebook-square"></i></a></li>
                            <li><a href="https://twitter.com/gospelchristmin?lang=fr" target="_blank"><i class="fab fa-twitter-square"></i></a></li>
                            <li><a href="https://www.youtube.com/user/GCM1207" target="_blank"><i class="fab fa-youtube"></i></a></li>
                            <li><a href="#"><i class="fab fa-google-plus" target="_blank"></i></a></li>
                            <li><a href="http://www.instagram.com/GCM_MEDIAHOUSE" target="_blank"><i class="fab fa-instagram"></i></a></li>
                          </ul>
                  </div>
              </div>
            </div>
		<script src="bootstrap/js/bootstrap.min.js"></script>


    </body>  
</html>
