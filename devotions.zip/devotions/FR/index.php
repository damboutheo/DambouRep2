<?php
session_start();
include_once('includes.php');

if(isset($_SESSION['pseudo'])){
	header('Location: accueil.php');
	exit;
}

if(!empty($_POST)){
	extract($_POST);
	$valid = true;
	
	
	if($valid){
		
		
	}
	
}	
?>

<!DOCTYPE html>
<html lang="fr">
	<header>
		
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<script src="https://kit.fontawesome.com/32597ef393.js" crossorigin="anonymous"></script>
		<title>Gospel of Christ Ministries</title>
		<link href="https://fonts.googleapis.com/css?family=EB+Garamond&display=swap" rel="stylesheet">
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
       <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<link href="bootstrap/js/bootstrap.js" rel="stylesheet" type="text/css"/>
		<link href="style.css" rel="stylesheet" type="text/css" media="screen"/>
		
		
	</header>
	
	<body>
	<!-- <div class="parallax"></div> -->
	<div style="height:500px;background-color:transparent">
		<nav class="navbar navbar-default">
		  <div class="container-fluid">
		    
		    <div class="navbar-header">
		      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		      </button>
		      <!-- <a class="navbar-brand" href="#">Tutoss</a>  -->
			  <img class="navbar-brands" src="IMG/logo.png" alt="Gospel of christ Ministries" >
		    </div>
			
			<div class="navbar-brand"><a href="https://www.gospelofchristministries.org">www.gospelofchristministries.org</a></div> 
		    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav navbar-right">
			    <!-- <li><a href="inscription.php">S'incrire</a></li> -->
		        <li><a href="connexion.php">Se connecter</a></li>
		      </ul>
		    </div>
		  </div>
		</nav>
		
		<div class="index-h1"><span><h1><strong>DEVOTIONS EN CHRIST</strong></h1></span><br></div><div class="theo">Drs Shawn et Annie SMITH</div> <br><div class="the">366 Jours de méditation des richesses insondables de
Christ.</div>
		
		<div class="container-fluid jump">
			
			<div class="col-xs-6 col-sm-6 col-md-6">
				<!-- <button class="insc" type="button" onclick="self.location.href='inscription.php'">S'inscrire</button> -->
				
			</div>
			
			<div class="col-xs-6 col-sm-6 col-md-6">
			
				<!-- <button class="conn" type="button" onclick="self.location.href='connexion.php'">Se connecter</button> -->
			</div>
			
			
			
			
		
		</div>
</div>
		<!-- <div class="parallax1"></div> -->
		
		<div class="footers">
                <div class="copy">© 2020 Gospel of Christ Ministries</div>
                    <div class="social-media">
                          <ul>
                            <li><a href="https://www.facebook.com/GospelOfChristMinistries/?fref=ts" target="_blank"><i class="fab fa-facebook-square"></i></a></li>
                            <li><a href="https://twitter.com/gospelchristmin?lang=fr" target="_blank"><i class="fab fa-twitter-square"></i></a></li>
                            <li><a href="https://www.youtube.com/user/GCM1207" target="_blank"><i class="fab fa-youtube"></i></a></li>
                            <li><a href="#"><i class="fab fa-google-plus" target="_blank"></i></a></li>
                            <li><a href="http://www.instagram.com/GCM_MEDIAHOUSE" target="_blank"><i class="fab fa-instagram"></i></a></li>
                          </ul>
                  </div>
              </div>
            </div>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>
	</body>
	
</html>