<?php
session_start();
include_once('includes.php');

if(isset($_SESSION['pseudo'])){
	header('Location: accueil.php');
	exit;
}

if(!empty($_POST)){
	extract($_POST);
	$valid = true;
	
	$Mail = htmlspecialchars(trim($Mail));
	$Password = trim($Password);
		
	if(empty($Mail)){
		$valid = false;
		$_SESSION['flash']['warning'] = "Veuillez saisir votre adresse mail !";
	}
	
	if(empty($Password)){
		$valid = false;
		$error_password = "Veuillez saisir votre mot de passe!";
	}
	
	
	$req = $DB->query('Select * from user where mail = :mail and password = :password', array('mail' => $Mail, 'password' => crypt($Password, '$2a$10$1qAz2wSx3eDc4rFv5tGb5t')));
	$req = $req->fetch();
		
	if(!$req['mail']){
		$valid = false;
		$_SESSION['flash']['danger'] = "Votre mail ou votre mot de passe ne correspond pas";
	}
	
	
	if($valid){
		
		//$_SESSION['id'] = $req['id'];
		$_SESSION['id'] = $req['idpublic'];
		$_SESSION['pseudo'] = $req['pseudo'];
		$_SESSION['mail'] = $req['mail'];
		$_SESSION['password'] = $req['password'];
		
		$_SESSION['flash']['info'] = "Hello " . $_SESSION['pseudo'];
		header('Location: accueil.php');
		exit;
			
	}
	
}	
?>

<!DOCTYPE html>
<html lang="fr">
	<head>
		<script src="https://kit.fontawesome.com/32597ef393.js" crossorigin="anonymous"></script>
		<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
		<link href="bootstrap/js/bootstrap.js" rel="stylesheet" type="text/css"/>
		<link href="style.css" rel="stylesheet" type="text/css" media="screen"/>
		
		<title>Sign In</title>
	</head>
	
	<body>
		
		<nav class="navbar navbar-default">
		  <div class="container-fluid">
		  <img class="navbar-brands" src="IMG/Logo.png" alt="Gospel of christ Ministries" >
		    <div class="navbar-header">
		      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		      </button>
		      <a class="navbar-brand" href="./"></a>
		    </div>
		
		    
		    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		      <ul class="nav navbar-nav">
		      </ul>
		      <ul class="nav navbar-nav navbar-right">
		        <!-- <li><a href="inscription.php">S'inscrire</a></li> -->
		        <li class="active"><a href="connexion.php">Sign In <span class="sr-only">(current)</span></a></li>
		      </ul>
		    </div>
		  </div>
		</nav>
		
		<?php 
		    if(isset($_SESSION['flash'])){ 
		        foreach($_SESSION['flash'] as $type => $message): ?>
				<div id="alert" class="alert alert-<?= $type; ?> infoMessage"><a class="close">X</span></a>
					<?= $message; ?>
				</div>	
		    
			<?php
			    endforeach;
			    unset($_SESSION['flash']);
			}
		?> 

	<div class="container-fluid">
		<div class="bording">		
	        <div class="row">
		        
	            <div class="col-xs-1 col-sm-2 col-md-3"></div>
	            <div class="col-xs-10 col-sm-8 col-md-6">
		            
		            <h1 class="index-h1">Se connecter</h1>
		            
		            <br/>
	                
	                <form class="con-form" method="post" action="">
	                    
                        <label>Email</label>
	
                    	<input class="input" type="email" name="Mail" placeholder="Email" value="<?php if (isset($Mail)) echo $Mail; ?>" required="required">	

						<br/>
						
	                    <label>Mot de passe</label>
	                    	
                    	<br/>
						<?php
							if(isset($error_password)){
								echo $error_password."<br/>";
							}	
						?>

                        <input class="input" type="password" name="Password" placeholder="Mot de passe" value="<?php if (isset($Password)) echo $Password; ?>" required="required">

	
	
	                    <div class="row">
	                        <div class="col-xs-0 col-sm-10 col-md-2"></div>
	                        <div class="col-xs-12 col-sm-2 col-md-8">
								<button type="submit">Se connecter</button>
	                        </div>
	                        <div class="col-xs-0 col-sm-1 col-md-2"></div>                                
	                   </div>
	
	                </form>
	                <a href="index.php"><h5>Retour page d'accueil</h5></a>
	            </div>
	
	            <div class="col-xs-0 col-sm-2 col-md-3"></div>
	        </div>
        </div>
	</div>
	<div class="footers">
                <div class="copy">© 2020 Gospel of Christ Ministries</div>
                    <div class="social-media">
                          <ul>
                            <li><a href="https://www.facebook.com/GospelOfChristMinistries/?fref=ts" target="_blank"><i class="fab fa-facebook-square"></i></a></li>
                            <li><a href="https://twitter.com/gospelchristmin?lang=fr" target="_blank"><i class="fab fa-twitter-square"></i></a></li>
                            <li><a href="https://www.youtube.com/user/GCM1207" target="_blank"><i class="fab fa-youtube"></i></a></li>
                            <li><a href="#"><i class="fab fa-google-plus" target="_blank"></i></a></li>
                            <li><a href="http://www.instagram.com/GCM_MEDIAHOUSE" target="_blank"><i class="fab fa-instagram"></i></a></li>
                          </ul>
                  </div>
              </div>
            </div>
		<script src="bootstrap/js/bootstrap.min.js"></script>
	</body>
</html>
