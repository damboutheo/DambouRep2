<?php
require("database.php");
initMigration($pdo);
if ($_SERVER['REQUEST_METHOD'] == "GET") {
//   $langue = $_GET["langue"];
  $date = $_GET["date_mes"];
  try{
    $statement = $pdo->prepare(
      'SELECT id, title, langue, DATE_FORMAT(date_mes, "%d") as date_mes, description, reference, penseedujour, confession
      FROM message 
      WHERE langue = "Français" AND date_mes = :date_mes
    ;'
    );
    $statement->execute(["date_mes" => $date]);
    

    $results = $statement->fetchAll(PDO::FETCH_OBJ);
    //echo "Read from table users</br>";
  }catch (PDOException $e) {
      echo "<h4 style='color: red;'>".$e->getMessage(). "</h4>";
  }
}
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
        <title>Gospel of Crist Ministries</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="https://kit.fontawesome.com/32597ef393.js" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=EB+Garamond&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Kaushan+Script&display=swap" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <link rel="stylesheet" type="text/css" media="screen" href="CSS/main.css" />
      <script src="main.js"></script>
  </head>
  <body>
      <header>
         <!-- <div class="icon-img"><img src="IMG//Logo.png" alt="Gospel of Christ ministry"></div> -->
        <!-- <a href="connexion2.php">Administration</a> -->
        <a href="accueil.php">Lire un nouveau devotionnel</a>
      </header>
          
            <?php foreach ($results as $message) { ?>
       <div class="container">
           <div class="heading">
               <h1><?php echo $message->title;?></h1><br>
           </div>
           <h1>Jour <?php echo $message->date_mes?></h1>
               <div class="row">
                    <div class="col-sm-4">
                        <div class="ref">
                            <div class="script"><h1>Reférence biblique</h1></div>
                           <P> <?php echo $message->reference;?></p><br>
                            <style>.inter{
                                color: white;
                            }</style>
                            
                        </div>
                    </div>
                    <div class="col-sm-4">
                    <div class="thumbnail"><p><?php echo $message->description;?></p><br></div>
                    </div>
                    <div class="col-sm-4">
                        <div class="pensee">
                            <div class="pens"><h1>Pensée du jour</h1></div>
                            <?php echo $message->penseedujour;?><br>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4">
                        
                    </div>
                    <div class="col-sm-4">
                    <div class="conf">
                        <div class="confi"><h1>Confession de foi</h1></div>
                        <?php echo $message->confession;?><br>
                    </div>
                    </div>
                    <div class="col-sm-4">
                    
                    </div>
                </div> 
            </div>
              
        
           
       <?php } ?>
       <div class="footers">
                <div class="copy">© 2020 Gospel of Christ Ministries</div>
                    <div class="social-media">
                          <ul>
                            <li><a href="https://www.facebook.com/GospelOfChristMinistries/?fref=ts" target="_blank"><i class="fab fa-facebook-square"></i></a></li>
                            <li><a href="https://twitter.com/gospelchristmin?lang=fr" target="_blank"><i class="fab fa-twitter-square"></i></a></li>
                            <li><a href="https://www.youtube.com/user/GCM1207" target="_blank"><i class="fab fa-youtube"></i></a></li>
                            <li><a href="#"><i class="fab fa-google-plus" target="_blank"></i></a></li>
                            <li><a href="http://www.instagram.com/GCM_MEDIAHOUSE" target="_blank"><i class="fab fa-instagram"></i></a></li>
                          </ul>
                  </div>
              </div>
            </div>
       <script src="bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>
