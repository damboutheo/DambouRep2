<?php
require("database.php");
//Create new Users
if ($_SERVER['REQUEST_METHOD'] == "POST") {
  $title = $_POST["title"];
  $langue = $_POST["langue"];
  $date = $_POST["date_mes"];
  $description = $_POST["description"];
  $reference = $_POST["reference"];
  //$pensee = isset($_POST["penseedujour"]) ? $_POST["penseedujour"] : NULL;
  $pensee = $_POST["penseedujour"];
  $confession = $_POST["confession"];
  try {
    $statement = $pdo->prepare(
      'INSERT INTO message (title,langue,date_mes,description,reference,penseedujour,confession) VALUES
      (:title, :langue, :date_mes, :description, :reference, :penseedujour, :confession);'
    );
    $statement->execute(['title'=> $title, 'langue'=> $langue, 'date_mes'=> $date, 'description'=> $description,
    'reference'=>$reference, 'penseedujour'=>$pensee, 'confession'=>$confession]);
    echo "Insert message: {$title}";
    $id = $pdo->lastInsertId();

    // echo "<script>location.href='reads.php?show=one&id={$id}' </script>";
  } catch (PDOException $e) {
      echo "<h4 style='color: red;'>".$e->getMessage(). "</h4>";
  }

}
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <title>Devotional</title>
      <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" type="text/css" media="screen" href="CSS/create.css" />
      <script src="script.js"></script>
  </head>
  <body>
  <header>
        <!-- <div class="icon-img"><img src="IMG//Logo.png" alt="Gospel of Christ ministry"></div> -->
        <!-- <a href="create.php">Administration</a> -->
        <a href="accueil.php">Read new devotion</a>
      </header>
      <form class="creating" action="create.php" method="POST">
        <label for="title">Title:</label><br>
        <input type="text" name="title" placeholder="Title" value="" class="text"><br>
        <label for="langue">Language:</label><br>
        <select name="langue" class="text">
        <option value="English">English</option>
    <option value="Français">Français</option>
      </select><br>
        <label for="date_mes">Date:</label><br>
        <input type="date" name="date_mes" value= "" class="text"><br>
        <label for="description">Content:</label><br>
        <textarea name="description" placeholder="Content" rows="20" cols="80" ></textarea><br>
        <div class="extra">
        <label for="reference">Scripture reference:</label><br>
        <textarea name="reference" placeholder="Scripture reference" rows="10" cols="50" ></textarea><br>
        <label for="penseedujour">Thougth of the day:</label><br>
        <textarea name="penseedujour" placeholder="Thougth of the day" rows="10" cols="50" ></textarea><br>
        <label for="confession">Confession of faith:</label><br>
        <textarea name="confession" placeholder="Confession of faith" rows="10" cols="50" ></textarea><br>
        </div>
        <!-- <button type="Submit" name="Save">Save</button> -->
        <input type="submit" value="Save" class="button"/><input type="reset" value="Reset" class="button"/>

      </form>
  </body>
</html>
