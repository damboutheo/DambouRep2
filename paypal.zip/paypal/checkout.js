/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' &amp;&amp; Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode &amp; 1: value is a module id, require it
/******/ 	// mode &amp; 2: merge all properties of value into the ns
/******/ 	// mode &amp; 4: return value when already ns object
/******/ 	// mode &amp; 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode &amp; 1) value = __webpack_require__(value);
/******/ 		if(mode &amp; 8) return value;
/******/ 		if((mode &amp; 4) &amp;&amp; typeof value === 'object' &amp;&amp; value &amp;&amp; value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode &amp; 2 &amp;&amp; typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module &amp;&amp; module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 62);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

    "use strict";

    // CONCATENATED MODULE: ./src/constants/button.js
    var BUTTON_STYLE_OPTIONS = {
      LABEL: 'label',
      SIZE: 'size',
      SHAPE: 'shape',
      COLOR: 'color',
      LAYOUT: 'layout',
      MAXBUTTONS: 'maxbuttons',
      FUNDINGICONS: 'fundingicons',
      BRANDING: 'branding',
      TAGLINE: 'tagline',
      HEIGHT: 'height',
      INSTALLMENTPERIOD: 'installmentperiod'
    };
    var BUTTON_LABEL = {
      PAYPAL: 'paypal',
      CHECKOUT: 'checkout',
      PAY: 'pay',
      CREDIT: 'credit',
      CARD: 'card',
      BUYNOW: 'buynow',
      INSTALLMENT: 'installment',
      VENMO: 'venmo',
      ITAU: 'itau',
      IDEAL: 'ideal',
      ELV: 'elv',
      BANCONTACT: 'bancontact',
      GIROPAY: 'giropay',
      SOFORT: 'sofort',
      EPS: 'eps',
      MYBANK: 'mybank',
      P24: 'p24',
      PAYU: 'payu',
      VERKKOPANKKI: 'verkkopankki',
      BLIK: 'blik',
      TRUSTLY: 'trustly',
      MAXIMA: 'maxima',
      BOLETO: 'boleto',
      OXXO: 'oxxo'
    };
    var BUTTON_COLOR = {
      GOLD: 'gold',
      BLUE: 'blue',
      SILVER: 'silver',
      BLACK: 'black',
      DARKBLUE: 'darkblue',
      WHITE: 'white',
      TRANSPARENT: 'transparent'
    };
    var BUTTON_LOGO_COLOR = {
      BLUE: 'blue',
      WHITE: 'white',
      BLACK: 'black',
      ANY: 'any'
    };
    var BUTTON_SIZE = {
      TINY: 'tiny',
      SMALL: 'small',
      MEDIUM: 'medium',
      LARGE: 'large',
      HUGE: 'huge',
      RESPONSIVE: 'responsive'
    };
    var BUTTON_TAGLINE_COLOR = {
      BLACK: 'black',
      BLUE: 'blue'
    };
    var BUTTON_SHAPE = {
      PILL: 'pill',
      RECT: 'rect'
    };
    var BUTTON_BRANDING = {
      BRANDED: 'branded',
      UNBRANDED: 'unbranded'
    };
    var BUTTON_LAYOUT = {
      HORIZONTAL: 'horizontal',
      VERTICAL: 'vertical'
    };
    var BUTTON_NUMBER = {
      SINGLE: 'single',
      MULTIPLE: 'multiple'
    };
    var BUTTON_LOGO = {
      PP: 'pp',
      PAYPAL: 'paypal',
      VENMO: 'venmo',
      ITAU: 'itau',
      CREDIT: 'credit',
      IDEAL: 'ideal',
      ELV: 'elv',
      BANCONTACT: 'bancontact',
      GIROPAY: 'giropay',
      SOFORT: 'sofort',
      EPS: 'eps',
      MYBANK: 'mybank',
      P24: 'p24',
      PAYU: 'payu',
      VERKKOPANKKI: 'verkkopankki',
      BLIK: 'blik',
      TRUSTLY: 'trustly',
      MAXIMA: 'maxima',
      BOLETO: 'boleto',
      OXXO: 'oxxo'
    };
    // CONCATENATED MODULE: ./src/constants/checkout.js
    var CHECKOUT_OVERLAY_COLOR = {
      BLACK: 'black',
      WHITE: 'white'
    };
    // CONCATENATED MODULE: ./src/constants/funding.js
    var FUNDING = {
      PAYPAL: 'paypal',
      VENMO: 'venmo',
      ITAU: 'itau',
      CREDIT: 'credit',
      CARD: 'card',
      IDEAL: 'ideal',
      ELV: 'elv',
      BANCONTACT: 'bancontact',
      GIROPAY: 'giropay',
      SOFORT: 'sofort',
      EPS: 'eps',
      MYBANK: 'mybank',
      P24: 'p24',
      ZIMPLER: 'zimpler',
      PAYU: 'payu',
      VERKKOPANKKI: 'verkkopankki',
      BLIK: 'blik',
      TRUSTLY: 'trustly',
      MAXIMA: 'maxima',
      BOLETO: 'boleto',
      OXXO: 'oxxo'
    };
    var CARD = {
      VISA: 'visa',
      MASTERCARD: 'mastercard',
      AMEX: 'amex',
      DISCOVER: 'discover',
      SWITCH: 'switch',
      MAESTRO: 'maestro',
      HIPER: 'hiper',
      ELO: 'elo',
      JCB: 'jcb',
      CUP: 'cup',
      COFINOGA: 'cofinoga',
      COFIDIS: 'cofidis',
      CETELEM: 'cetelem',
      CBNATIONALE: 'cbnationale'
    };
    var FUNDING_ELIGIBILITY_REASON = {
      PRIMARY: 'The funding source is the primary source',
      NOT_ENABLED: 'The funding source is not currently enabled for use',
      SECONDARY_DISALLOWED: 'The funding source is disallowed as a secondary button',
      OPT_OUT: 'The funding source was disallowed in funding.disallowed',
      OPT_IN: 'The funding source was allowed in funding.allowed',
      DISALLOWED_COUNTRY: 'The funding source is not enabled for the current locale',
      DEFAULT_COUNTRY: 'The funding source is enabled by default for the current locale',
      DEFAULT: 'The funding source is enabled by default for all users',
      REMEMBERED: 'The funding source was remembered for the current user',
      NEED_OPT_IN: 'The funding source needs to be allowed in funding.allowed',
      COMMIT_NOT_SET: 'The funding source is not enabled when commit is not set as true',
      INVALID_ENV: 'The funding source is not supported in this environment'
    };
    var CARD_PRIORITY = [CARD.VISA, CARD.MASTERCARD, CARD.AMEX, CARD.DISCOVER, CARD.SWITCH, CARD.MAESTRO, CARD.HIPER, CARD.ELO, CARD.JCB, CARD.CUP, CARD.COFINOGA, CARD.COFIDIS, CARD.CETELEM, CARD.CBNATIONALE];
    // CONCATENATED MODULE: ./src/constants/misc.js
    var ENV = {
      LOCAL: 'local',
      STAGE: 'stage',
      SANDBOX: 'sandbox',
      PRODUCTION: 'production',
      TEST: 'test',
      DEMO: 'demo'
    };
    var USERS = {
      ALL: 'all',
      REMEMBERED: 'remembered'
    };
    var SOURCE = {
      MANUAL: 'manual',
      BUTTON_FACTORY: 'button_factory'
    };
    var LOG_LEVEL = {
      DEBUG: 'debug',
      INFO: 'info',
      WARN: 'warn',
      ERROR: 'error'
    };
    var PAYMENT_TYPE = {
      EC_TOKEN: 'ec_token',
      BA_TOKEN: 'ba_token',
      PAY_ID: 'pay_id'
    };
    var PPTM_ID = 'xo-pptm';
    var ATTRIBUTE = {
      BUTTON: 'data-button',
      FUNDING_SOURCE: 'data-funding-source',
      CARD: 'data-card',
      VERSION: 'data-version',
      LAYOUT: 'data-layout',
      SIZE: 'data-size'
    };
    var PLATFORM = {
      DESKTOP: 'desktop',
      MOBILE: 'mobile'
    };
    var DEFAULT = 'default';
    // CONCATENATED MODULE: ./src/constants/fpti.js
    var _CONTEXT_TYPE;
    
    
    var FPTI = {
      KEY: {
        FEED: 'feed_name',
        STATE: 'state_name',
        TRANSITION: 'transition_name',
        BUTTON_TYPE: 'button_type',
        SESSION_UID: 'page_session_id',
        BUTTON_SESSION_UID: 'button_session_id',
        TOKEN: 'token',
        CONTEXT_ID: 'context_id',
        CONTEXT_TYPE: 'context_type',
        REFERER: 'referer_url',
        PAY_ID: 'pay_id',
        SELLER_ID: 'seller_id',
        DATA_SOURCE: 'serverside_data_source',
        BUTTON_SOURCE: 'button_source',
        ERROR_CODE: 'ext_error_code',
        ERROR_DESC: 'ext_error_desc',
        PAGE_LOAD_TIME: 'page_load_time',
        EXPERIMENT_NAME: 'pxp_exp_id',
        TREATMENT_NAME: 'pxp_trtmnt_id',
        TRANSITION_TIME: 'transition_time',
        FUNDING_LIST: 'eligible_payment_methods',
        FUNDING_COUNT: 'eligible_payment_count',
        CHOSEN_FUNDING: 'selected_payment_method',
        BUTTON_LAYOUT: 'button_layout',
        BUTTON_COLOR: 'button_color',
        BUTTON_SIZE: 'button_size',
        BUTTON_SHAPE: 'button_shape',
        BUTTON_LABEL: 'button_label',
        BUTTON_WIDTH: 'button_width',
        VERSION: 'checkoutjs_version',
        MAX_BUTTONS: 'max_buttons',
        FUNDING_REMEMBERED: 'funding_remembered',
        BUTTON_TAGLINE_ENABLED: 'button_tagline_enabled',
        RESPONSE_DURATION: 'response_duration',
        PAYMENT_FLOW: 'payment_flow',
        BUTTON_VERSION: 'button_version'
      },
      BUTTON_TYPE: {
        IFRAME: 'iframe',
        HTML: 'html',
        CUSTOM: 'custom'
      },
      DATA_SOURCE: {
        CHECKOUT: 'checkout'
      },
      CONTEXT_TYPE: (_CONTEXT_TYPE = {
        BUTTON_SESSION_ID: 'button_session_id'
      }, _CONTEXT_TYPE[PAYMENT_TYPE.PAY_ID] = 'Pay-ID', _CONTEXT_TYPE[PAYMENT_TYPE.EC_TOKEN] = 'EC-Token', _CONTEXT_TYPE[PAYMENT_TYPE.BA_TOKEN] = 'EC-Token', _CONTEXT_TYPE),
      FEED: {
        CHECKOUTJS: 'checkoutjs'
      },
      STATE: {
        LOAD: 'checkoutjs_load',
        BUTTON: 'checkoutjs_button',
        CHECKOUT: 'checkoutjs_checkout',
        PPTM: 'checkoutjs_pptm'
      },
      TRANSITION: {
        SCRIPT_LOAD: 'process_script_load',
        BUTTON_RENDER: 'process_button_render',
        BUTTON_LOAD: 'process_button_load',
        BUTTON_CLICK: 'process_button_click',
        BUTTON_RENDER_INTRANET_MODE: 'process_button_render_intranet_mode',
        BUTTON_CLICK_INTRANET_MODE: 'process_button_click_intranet_mode',
        CREATE_PAYMENT: 'process_create_payment',
        RECIEVE_PAYMENT: 'process_recieve_payment',
        CHECKOUT_INIT: 'process_checkout_init',
        CHECKOUT_AUTHORIZE: 'process_checkout_authorize',
        CHECKOUT_SHIPPING_CHANGE: 'process_checkout_shipping_change',
        CHECKOUT_CANCEL: 'process_checkout_cancel',
        CHECKOUT_ERROR: 'process_checkout_error',
        EXTERNAL_EXPERIMENT: 'process_external_experiment',
        EXTERNAL_EXPERIMENT_COMPLETE: 'process_external_experiment_complete',
        PPTM_LOAD: 'process_pptm_load',
        PPTM_LOADED: 'process_pptm_loaded'
      }
    };
    // CONCATENATED MODULE: ./src/constants/country.js
    var _LANG_TO_DEFAULT_COUN;
    
    var COUNTRY = {
      AD: 'AD',
      AE: 'AE',
      AG: 'AG',
      AI: 'AI',
      AL: 'AL',
      AM: 'AM',
      AN: 'AN',
      AO: 'AO',
      AR: 'AR',
      AT: 'AT',
      AU: 'AU',
      AW: 'AW',
      AZ: 'AZ',
      BA: 'BA',
      BB: 'BB',
      BE: 'BE',
      BF: 'BF',
      BG: 'BG',
      BH: 'BH',
      BI: 'BI',
      BJ: 'BJ',
      BM: 'BM',
      BN: 'BN',
      BO: 'BO',
      BR: 'BR',
      BS: 'BS',
      BT: 'BT',
      BW: 'BW',
      BY: 'BY',
      BZ: 'BZ',
      C2: 'C2',
      CA: 'CA',
      CD: 'CD',
      CG: 'CG',
      CH: 'CH',
      CI: 'CI',
      CK: 'CK',
      CL: 'CL',
      CM: 'CM',
      CN: 'CN',
      CO: 'CO',
      CR: 'CR',
      CV: 'CV',
      CY: 'CY',
      CZ: 'CZ',
      DE: 'DE',
      DJ: 'DJ',
      DK: 'DK',
      DM: 'DM',
      DO: 'DO',
      DZ: 'DZ',
      EC: 'EC',
      EE: 'EE',
      EG: 'EG',
      ER: 'ER',
      ES: 'ES',
      ET: 'ET',
      FI: 'FI',
      FJ: 'FJ',
      FK: 'FK',
      FM: 'FM',
      FO: 'FO',
      FR: 'FR',
      GA: 'GA',
      GB: 'GB',
      GD: 'GD',
      GE: 'GE',
      GF: 'GF',
      GI: 'GI',
      GL: 'GL',
      GM: 'GM',
      GN: 'GN',
      GP: 'GP',
      GR: 'GR',
      GT: 'GT',
      GW: 'GW',
      GY: 'GY',
      HK: 'HK',
      HN: 'HN',
      HR: 'HR',
      HU: 'HU',
      ID: 'ID',
      IE: 'IE',
      IL: 'IL',
      IN: 'IN',
      IS: 'IS',
      IT: 'IT',
      JM: 'JM',
      JO: 'JO',
      JP: 'JP',
      KE: 'KE',
      KG: 'KG',
      KH: 'KH',
      KI: 'KI',
      KM: 'KM',
      KN: 'KN',
      KR: 'KR',
      KW: 'KW',
      KY: 'KY',
      KZ: 'KZ',
      LA: 'LA',
      LC: 'LC',
      LI: 'LI',
      LK: 'LK',
      LS: 'LS',
      LT: 'LT',
      LU: 'LU',
      LV: 'LV',
      MA: 'MA',
      MC: 'MC',
      MD: 'MD',
      ME: 'ME',
      MG: 'MG',
      MH: 'MH',
      MK: 'MK',
      ML: 'ML',
      MN: 'MN',
      MQ: 'MQ',
      MR: 'MR',
      MS: 'MS',
      MT: 'MT',
      MU: 'MU',
      MV: 'MV',
      MW: 'MW',
      MX: 'MX',
      MY: 'MY',
      MZ: 'MZ',
      NA: 'NA',
      NC: 'NC',
      NE: 'NE',
      NF: 'NF',
      NG: 'NG',
      NI: 'NI',
      NL: 'NL',
      NO: 'NO',
      NP: 'NP',
      NR: 'NR',
      NU: 'NU',
      NZ: 'NZ',
      OM: 'OM',
      PA: 'PA',
      PE: 'PE',
      PF: 'PF',
      PG: 'PG',
      PH: 'PH',
      PL: 'PL',
      PM: 'PM',
      PN: 'PN',
      PT: 'PT',
      PW: 'PW',
      PY: 'PY',
      QA: 'QA',
      RE: 'RE',
      RO: 'RO',
      RS: 'RS',
      RU: 'RU',
      RW: 'RW',
      SA: 'SA',
      SB: 'SB',
      SC: 'SC',
      SE: 'SE',
      SG: 'SG',
      SH: 'SH',
      SI: 'SI',
      SJ: 'SJ',
      SK: 'SK',
      SL: 'SL',
      SM: 'SM',
      SN: 'SN',
      SO: 'SO',
      SR: 'SR',
      ST: 'ST',
      SV: 'SV',
      SZ: 'SZ',
      TC: 'TC',
      TD: 'TD',
      TG: 'TG',
      TH: 'TH',
      TJ: 'TJ',
      TM: 'TM',
      TN: 'TN',
      TO: 'TO',
      TR: 'TR',
      TT: 'TT',
      TV: 'TV',
      TW: 'TW',
      TZ: 'TZ',
      UA: 'UA',
      UG: 'UG',
      US: 'US',
      UY: 'UY',
      VA: 'VA',
      VC: 'VC',
      VE: 'VE',
      VG: 'VG',
      VN: 'VN',
      VU: 'VU',
      WF: 'WF',
      WS: 'WS',
      YE: 'YE',
      YT: 'YT',
      ZA: 'ZA',
      ZM: 'ZM',
      ZW: 'ZW'
    };
    var LANG = {
      AR: 'ar',
      CS: 'cs',
      DA: 'da',
      DE: 'de',
      EL: 'el',
      EN: 'en',
      ES: 'es',
      FI: 'fi',
      FR: 'fr',
      HE: 'he',
      HU: 'hu',
      ID: 'id',
      IT: 'it',
      JA: 'ja',
      KO: 'ko',
      NL: 'nl',
      NO: 'no',
      PL: 'pl',
      PT: 'pt',
      RU: 'ru',
      SK: 'sk',
      SV: 'sv',
      TH: 'th',
      TR: 'tr',
      ZH: 'zh'
    };
    var LANG_TO_DEFAULT_COUNTRY = (_LANG_TO_DEFAULT_COUN = {}, _LANG_TO_DEFAULT_COUN[LANG.AR] = COUNTRY.SA, _LANG_TO_DEFAULT_COUN[LANG.CS] = COUNTRY.CZ, _LANG_TO_DEFAULT_COUN[LANG.DA] = COUNTRY.DK, _LANG_TO_DEFAULT_COUN[LANG.DE] = COUNTRY.DE, _LANG_TO_DEFAULT_COUN[LANG.EL] = COUNTRY.GR, _LANG_TO_DEFAULT_COUN[LANG.EN] = COUNTRY.US, _LANG_TO_DEFAULT_COUN[LANG.ES] = COUNTRY.ES, _LANG_TO_DEFAULT_COUN[LANG.FI] = COUNTRY.FI, _LANG_TO_DEFAULT_COUN[LANG.FR] = COUNTRY.FR, _LANG_TO_DEFAULT_COUN[LANG.HE] = COUNTRY.IL, _LANG_TO_DEFAULT_COUN[LANG.HU] = COUNTRY.HU, _LANG_TO_DEFAULT_COUN[LANG.ID] = COUNTRY.ID, _LANG_TO_DEFAULT_COUN[LANG.IT] = COUNTRY.IT, _LANG_TO_DEFAULT_COUN[LANG.JA] = COUNTRY.JP, _LANG_TO_DEFAULT_COUN[LANG.KO] = COUNTRY.KR, _LANG_TO_DEFAULT_COUN[LANG.NL] = COUNTRY.NL, _LANG_TO_DEFAULT_COUN[LANG.NO] = COUNTRY.NO, _LANG_TO_DEFAULT_COUN[LANG.PL] = COUNTRY.PL, _LANG_TO_DEFAULT_COUN[LANG.PT] = COUNTRY.PT, _LANG_TO_DEFAULT_COUN[LANG.RU] = COUNTRY.RU, _LANG_TO_DEFAULT_COUN[LANG.SK] = COUNTRY.SK, _LANG_TO_DEFAULT_COUN[LANG.SV] = COUNTRY.SE, _LANG_TO_DEFAULT_COUN[LANG.TH] = COUNTRY.TH, _LANG_TO_DEFAULT_COUN[LANG.TR] = COUNTRY.TR, _LANG_TO_DEFAULT_COUN[LANG.ZH] = COUNTRY.CN, _LANG_TO_DEFAULT_COUN);
    var ALLOWED_INSTALLMENT_COUNTRIES = [COUNTRY.BR, COUNTRY.MX];
    var ALLOWED_INSTALLMENT_PERIOD = {
      BR: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
      MX: [3, 6, 9, 12]
    };
    // CONCATENATED MODULE: ./src/constants/locale.js
    var _LOCALE;
    
    
    var LOCALE = (_LOCALE = {}, _LOCALE[COUNTRY.AD] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.AE] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH, LANG.AR], _LOCALE[COUNTRY.AG] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.AI] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.AL] = [LANG.EN], _LOCALE[COUNTRY.AM] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.AN] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.AO] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.AR] = [LANG.ES, LANG.EN], _LOCALE[COUNTRY.AT] = [LANG.DE, LANG.EN], _LOCALE[COUNTRY.AU] = [LANG.EN], _LOCALE[COUNTRY.AW] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.AZ] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.BA] = [LANG.EN], _LOCALE[COUNTRY.BB] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.BE] = [LANG.EN, LANG.NL, LANG.FR], _LOCALE[COUNTRY.BF] = [LANG.FR, LANG.EN, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.BG] = [LANG.EN], _LOCALE[COUNTRY.BH] = [LANG.AR, LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.BI] = [LANG.FR, LANG.EN, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.BJ] = [LANG.FR, LANG.EN, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.BM] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.BN] = [LANG.EN], _LOCALE[COUNTRY.BO] = [LANG.ES, LANG.EN, LANG.FR, LANG.ZH], _LOCALE[COUNTRY.BR] = [LANG.PT, LANG.EN], _LOCALE[COUNTRY.BS] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.BT] = [LANG.EN], _LOCALE[COUNTRY.BW] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.BY] = [LANG.EN], _LOCALE[COUNTRY.BZ] = [LANG.EN, LANG.ES, LANG.FR, LANG.ZH], _LOCALE[COUNTRY.C2] = [LANG.ZH, LANG.EN], _LOCALE[COUNTRY.CA] = [LANG.EN, LANG.FR], _LOCALE[COUNTRY.CD] = [LANG.FR, LANG.EN, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.CG] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.CH] = [LANG.DE, LANG.FR, LANG.EN], _LOCALE[COUNTRY.CI] = [LANG.FR, LANG.EN], _LOCALE[COUNTRY.CK] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.CL] = [LANG.ES, LANG.EN, LANG.FR, LANG.ZH], _LOCALE[COUNTRY.CM] = [LANG.FR, LANG.EN], _LOCALE[COUNTRY.CN] = [LANG.ZH], _LOCALE[COUNTRY.CO] = [LANG.ES, LANG.EN, LANG.FR, LANG.ZH], _LOCALE[COUNTRY.CR] = [LANG.ES, LANG.EN, LANG.FR, LANG.ZH], _LOCALE[COUNTRY.CV] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.CY] = [LANG.EN], _LOCALE[COUNTRY.CZ] = [LANG.CS, LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.DE] = [LANG.DE, LANG.EN], _LOCALE[COUNTRY.DJ] = [LANG.FR, LANG.EN, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.DK] = [LANG.DA, LANG.EN], _LOCALE[COUNTRY.DM] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.DO] = [LANG.ES, LANG.EN, LANG.FR, LANG.ZH], _LOCALE[COUNTRY.DZ] = [LANG.AR, LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.EC] = [LANG.ES, LANG.EN, LANG.FR, LANG.ZH], _LOCALE[COUNTRY.EE] = [LANG.EN, LANG.RU, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.EG] = [LANG.AR, LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.ER] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.ES] = [LANG.ES, LANG.EN], _LOCALE[COUNTRY.ET] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.FI] = [LANG.FI, LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.FJ] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.FK] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.FM] = [LANG.EN], _LOCALE[COUNTRY.FO] = [LANG.DA, LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.FR] = [LANG.FR, LANG.EN], _LOCALE[COUNTRY.GA] = [LANG.FR, LANG.EN, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.GB] = [LANG.EN], _LOCALE[COUNTRY.GD] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.GE] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.GF] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.GI] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.GL] = [LANG.DA, LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.GM] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.GN] = [LANG.FR, LANG.EN, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.GP] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.GR] = [LANG.EL, LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.GT] = [LANG.ES, LANG.EN, LANG.FR, LANG.ZH], _LOCALE[COUNTRY.GW] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.GY] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.HK] = [LANG.EN, LANG.ZH], _LOCALE[COUNTRY.HN] = [LANG.ES, LANG.EN, LANG.FR, LANG.ZH], _LOCALE[COUNTRY.HR] = [LANG.EN], _LOCALE[COUNTRY.HU] = [LANG.HU, LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.ID] = [LANG.ID, LANG.EN], _LOCALE[COUNTRY.IE] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.IL] = [LANG.HE, LANG.EN], _LOCALE[COUNTRY.IN] = [LANG.EN], _LOCALE[COUNTRY.IS] = [LANG.EN], _LOCALE[COUNTRY.IT] = [LANG.IT, LANG.EN], _LOCALE[COUNTRY.JM] = [LANG.EN, LANG.ES, LANG.FR, LANG.ZH], _LOCALE[COUNTRY.JO] = [LANG.AR, LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.JP] = [LANG.JA, LANG.EN], _LOCALE[COUNTRY.KE] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.KG] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.KH] = [LANG.EN], _LOCALE[COUNTRY.KI] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.KM] = [LANG.FR, LANG.EN, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.KN] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.KR] = [LANG.KO, LANG.EN], _LOCALE[COUNTRY.KW] = [LANG.AR, LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.KY] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.KZ] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.LA] = [LANG.EN], _LOCALE[COUNTRY.LC] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.LI] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.LK] = [LANG.EN], _LOCALE[COUNTRY.LS] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.LT] = [LANG.EN, LANG.RU, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.LU] = [LANG.EN, LANG.DE, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.LV] = [LANG.EN, LANG.RU, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.MA] = [LANG.AR, LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.MC] = [LANG.FR, LANG.EN], _LOCALE[COUNTRY.MD] = [LANG.EN], _LOCALE[COUNTRY.ME] = [LANG.EN], _LOCALE[COUNTRY.MG] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.MH] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.MK] = [LANG.EN], _LOCALE[COUNTRY.ML] = [LANG.FR, LANG.EN, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.MN] = [LANG.EN], _LOCALE[COUNTRY.MQ] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.MR] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.MS] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.MT] = [LANG.EN], _LOCALE[COUNTRY.MU] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.MV] = [LANG.EN], _LOCALE[COUNTRY.MW] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.MX] = [LANG.ES, LANG.EN], _LOCALE[COUNTRY.MY] = [LANG.EN], _LOCALE[COUNTRY.MZ] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.NA] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.NC] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.NE] = [LANG.FR, LANG.EN, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.NF] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.NG] = [LANG.EN], _LOCALE[COUNTRY.NI] = [LANG.ES, LANG.EN, LANG.FR, LANG.ZH], _LOCALE[COUNTRY.NL] = [LANG.NL, LANG.EN], _LOCALE[COUNTRY.NO] = [LANG.NO, LANG.EN], _LOCALE[COUNTRY.NP] = [LANG.EN], _LOCALE[COUNTRY.NR] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.NU] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.NZ] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.OM] = [LANG.AR, LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.PA] = [LANG.ES, LANG.EN, LANG.FR, LANG.ZH], _LOCALE[COUNTRY.PE] = [LANG.ES, LANG.EN, LANG.FR, LANG.ZH], _LOCALE[COUNTRY.PF] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.PG] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.PH] = [LANG.EN], _LOCALE[COUNTRY.PL] = [LANG.PL, LANG.EN], _LOCALE[COUNTRY.PM] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.PN] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.PT] = [LANG.PT, LANG.EN], _LOCALE[COUNTRY.PW] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.PY] = [LANG.ES, LANG.EN], _LOCALE[COUNTRY.QA] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH, LANG.AR], _LOCALE[COUNTRY.RE] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.RO] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.RS] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.RU] = [LANG.RU, LANG.EN], _LOCALE[COUNTRY.RW] = [LANG.FR, LANG.EN, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.SA] = [LANG.AR, LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.SB] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.SC] = [LANG.FR, LANG.EN, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.SE] = [LANG.SV, LANG.EN], _LOCALE[COUNTRY.SG] = [LANG.EN], _LOCALE[COUNTRY.SH] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.SI] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.SJ] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.SK] = [LANG.SK, LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.SL] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.SM] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.SN] = [LANG.FR, LANG.EN, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.SO] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.SR] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.ST] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.SV] = [LANG.ES, LANG.EN, LANG.FR, LANG.ZH], _LOCALE[COUNTRY.SZ] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.TC] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.TD] = [LANG.FR, LANG.EN, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.TG] = [LANG.FR, LANG.EN, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.TH] = [LANG.TH, LANG.EN], _LOCALE[COUNTRY.TJ] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.TM] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.TN] = [LANG.AR, LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.TO] = [LANG.EN], _LOCALE[COUNTRY.TR] = [LANG.TR, LANG.EN], _LOCALE[COUNTRY.TT] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.TV] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.TW] = [LANG.ZH, LANG.EN], _LOCALE[COUNTRY.TZ] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.UA] = [LANG.EN, LANG.RU, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.UG] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.US] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.UY] = [LANG.ES, LANG.EN, LANG.FR, LANG.ZH], _LOCALE[COUNTRY.VA] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.VC] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.VE] = [LANG.ES, LANG.EN, LANG.FR, LANG.ZH], _LOCALE[COUNTRY.VG] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.VN] = [LANG.EN], _LOCALE[COUNTRY.VU] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.WF] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.WS] = [LANG.EN], _LOCALE[COUNTRY.YE] = [LANG.AR, LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.YT] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.ZA] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.ZM] = [LANG.EN, LANG.FR, LANG.ES, LANG.ZH], _LOCALE[COUNTRY.ZW] = [LANG.EN], _LOCALE);
    // CONCATENATED MODULE: ./src/constants/index.js
    /* concated harmony reexport BUTTON_STYLE_OPTIONS */__webpack_require__.d(__webpack_exports__, "m", function() { return BUTTON_STYLE_OPTIONS; });
    /* concated harmony reexport BUTTON_LABEL */__webpack_require__.d(__webpack_exports__, "f", function() { return BUTTON_LABEL; });
    /* concated harmony reexport BUTTON_COLOR */__webpack_require__.d(__webpack_exports__, "e", function() { return BUTTON_COLOR; });
    /* concated harmony reexport BUTTON_LOGO_COLOR */__webpack_require__.d(__webpack_exports__, "i", function() { return BUTTON_LOGO_COLOR; });
    /* concated harmony reexport BUTTON_SIZE */__webpack_require__.d(__webpack_exports__, "l", function() { return BUTTON_SIZE; });
    /* concated harmony reexport BUTTON_TAGLINE_COLOR */__webpack_require__.d(__webpack_exports__, "n", function() { return BUTTON_TAGLINE_COLOR; });
    /* concated harmony reexport BUTTON_SHAPE */__webpack_require__.d(__webpack_exports__, "k", function() { return BUTTON_SHAPE; });
    /* concated harmony reexport BUTTON_BRANDING */__webpack_require__.d(__webpack_exports__, "d", function() { return BUTTON_BRANDING; });
    /* concated harmony reexport BUTTON_LAYOUT */__webpack_require__.d(__webpack_exports__, "g", function() { return BUTTON_LAYOUT; });
    /* concated harmony reexport BUTTON_NUMBER */__webpack_require__.d(__webpack_exports__, "j", function() { return BUTTON_NUMBER; });
    /* concated harmony reexport BUTTON_LOGO */__webpack_require__.d(__webpack_exports__, "h", function() { return BUTTON_LOGO; });
    /* concated harmony reexport CHECKOUT_OVERLAY_COLOR */__webpack_require__.d(__webpack_exports__, "q", function() { return CHECKOUT_OVERLAY_COLOR; });
    /* concated harmony reexport FUNDING */__webpack_require__.d(__webpack_exports__, "v", function() { return FUNDING; });
    /* concated harmony reexport CARD */__webpack_require__.d(__webpack_exports__, "o", function() { return CARD; });
    /* concated harmony reexport FUNDING_ELIGIBILITY_REASON */__webpack_require__.d(__webpack_exports__, "w", function() { return FUNDING_ELIGIBILITY_REASON; });
    /* concated harmony reexport CARD_PRIORITY */__webpack_require__.d(__webpack_exports__, "p", function() { return CARD_PRIORITY; });
    /* concated harmony reexport FPTI */__webpack_require__.d(__webpack_exports__, "u", function() { return FPTI; });
    /* concated harmony reexport COUNTRY */__webpack_require__.d(__webpack_exports__, "r", function() { return COUNTRY; });
    /* concated harmony reexport LANG */__webpack_require__.d(__webpack_exports__, "x", function() { return LANG; });
    /* concated harmony reexport LANG_TO_DEFAULT_COUNTRY */__webpack_require__.d(__webpack_exports__, "y", function() { return LANG_TO_DEFAULT_COUNTRY; });
    /* concated harmony reexport ALLOWED_INSTALLMENT_COUNTRIES */__webpack_require__.d(__webpack_exports__, "a", function() { return ALLOWED_INSTALLMENT_COUNTRIES; });
    /* concated harmony reexport ALLOWED_INSTALLMENT_PERIOD */__webpack_require__.d(__webpack_exports__, "b", function() { return ALLOWED_INSTALLMENT_PERIOD; });
    /* concated harmony reexport ENV */__webpack_require__.d(__webpack_exports__, "t", function() { return ENV; });
    /* concated harmony reexport USERS */__webpack_require__.d(__webpack_exports__, "F", function() { return USERS; });
    /* concated harmony reexport SOURCE */__webpack_require__.d(__webpack_exports__, "E", function() { return SOURCE; });
    /* concated harmony reexport LOG_LEVEL */__webpack_require__.d(__webpack_exports__, "A", function() { return LOG_LEVEL; });
    /* concated harmony reexport PAYMENT_TYPE */__webpack_require__.d(__webpack_exports__, "B", function() { return PAYMENT_TYPE; });
    /* concated harmony reexport PPTM_ID */__webpack_require__.d(__webpack_exports__, "D", function() { return PPTM_ID; });
    /* concated harmony reexport ATTRIBUTE */__webpack_require__.d(__webpack_exports__, "c", function() { return ATTRIBUTE; });
    /* concated harmony reexport PLATFORM */__webpack_require__.d(__webpack_exports__, "C", function() { return PLATFORM; });
    /* concated harmony reexport DEFAULT */__webpack_require__.d(__webpack_exports__, "s", function() { return DEFAULT; });
    /* concated harmony reexport LOCALE */__webpack_require__.d(__webpack_exports__, "z", function() { return LOCALE; });
    
    
    
    
    
    
    
    
    /***/ }),
    /* 1 */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    /* unused harmony export JsxHTMLNode */
    /* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return JsxHTMLNodeContainer; });
    /* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return jsxToHTML; });
    /* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return jsxRender; });
    /* harmony import */ var _babel_runtime_helpers_esm_inheritsLoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(22);
    /* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12);
    
    
    /** @jsx jsxToHTML */
     // eslint-disable-next-line no-use-before-define
    
    function htmlEncode(html) {
      if (html === void 0) {
        html = '';
      }
    
      return html.toString().replace(/&amp;/g, '&amp;amp;').replace(/&lt;/g, '&amp;lt;').replace(/&gt;/g, '&amp;gt;').replace(/"/g, '&amp;quot;').replace(/'/g, '&amp;#39;').replace(/\//g, '&amp;#x2F;');
    }
    
    var JsxHTMLNode =
    /*#__PURE__*/
    function () {
      function JsxHTMLNode(name, props, children) {
        this.name = void 0;
        this.props = void 0;
        this.children = void 0;
        this.name = name;
        this.props = props;
        this.children = children;
      }
    
      var _proto = JsxHTMLNode.prototype;
    
      _proto.toString = function toString() {
        return "&lt;" + this.name + (this.props ? ' ' : '') + (this.props ? this.propsToString() : '') + "&gt;" + this.childrenToString() + "&lt;/" + this.name + "&gt;";
      };
    
      _proto.propsToString = function propsToString() {
        var props = this.props;
    
        if (!props) {
          return '';
        }
    
        return Object.keys(props).filter(function (key) {
          return key !== 'innerHTML' &amp;&amp; props &amp;&amp; props[key] !== false;
        }).map(function (key) {
          if (props &amp;&amp; props[key] === true) {
            return "" + htmlEncode(key);
          }
    
          return props ? htmlEncode(key) + "=\"" + htmlEncode(props[key]) + "\"" : '';
        }).join(' ');
      };
    
      _proto.childrenToString = function childrenToString() {
        if (this.props &amp;&amp; this.props.innerHTML) {
          return this.props.innerHTML;
        }
    
        if (!this.children) {
          return '';
        }
    
        var result = '';
    
        function iterate(children) {
          for (var _i2 = 0; _i2 &lt; children.length; _i2++) {
            var child = children[_i2];
    
            if (child === null || child === undefined) {
              continue;
            }
    
            if (Array.isArray(child)) {
              iterate(child);
            } else if (child instanceof JsxHTMLNode) {
              result += child.toString();
            } else {
              result += htmlEncode(child);
            }
          }
        }
    
        iterate(this.children);
        return result;
      };
    
      return JsxHTMLNode;
    }();
    var JsxHTMLNodeContainer =
    /*#__PURE__*/
    function (_JsxHTMLNode) {
      Object(_babel_runtime_helpers_esm_inheritsLoose__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"])(JsxHTMLNodeContainer, _JsxHTMLNode);
    
      function JsxHTMLNodeContainer(children) {
        return _JsxHTMLNode.call(this, '', {}, children) || this;
      }
    
      var _proto2 = JsxHTMLNodeContainer.prototype;
    
      _proto2.toString = function toString() {
        return this.childrenToString();
      };
    
      return JsxHTMLNodeContainer;
    }(JsxHTMLNode);
    function jsxToHTML(name, props) {
      for (var _len = arguments.length, children = new Array(_len &gt; 2 ? _len - 2 : 0), _key = 2; _key &lt; _len; _key++) {
        children[_key - 2] = arguments[_key];
      }
    
      return new JsxHTMLNode(name, props, children);
    }
    function jsxRender(template, renderers) {
      // eslint-disable-next-line security/detect-unsafe-regex, unicorn/no-unsafe-regex
      var nodes = Object(_util__WEBPACK_IMPORTED_MODULE_1__[/* regexMap */ "n"])(template, /\{\s*([a-z]+)(?::\s*([^} ]+))?\s*\}|([^${}]+)/g, function (match, type, value, text) {
        if (type) {
          if (!renderers[type]) {
            throw new Error("Can not render type: " + type);
          }
    
          return renderers[type](value);
        } else if (text &amp;&amp; text.trim()) {
          if (!renderers.text) {
            return text;
          }
    
          if (/&lt;br&gt;/.test(text)) {
            return renderers.break(text);
          } else {
            return renderers.text(text);
          }
        } else {
          return text;
        }
      });
      return new JsxHTMLNodeContainer(nodes);
    }
    
    /***/ }),
    /* 2 */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    
    // CONCATENATED MODULE: ./node_modules/zalgo-promise/src/utils.js
    function utils_isPromise(item) {
      try {
        if (!item) {
          return false;
        }
    
        if (typeof Promise !== 'undefined' &amp;&amp; item instanceof Promise) {
          return true;
        }
    
        if (typeof window !== 'undefined' &amp;&amp; typeof window.Window === 'function' &amp;&amp; item instanceof window.Window) {
          return false;
        }
    
        if (typeof window !== 'undefined' &amp;&amp; typeof window.constructor === 'function' &amp;&amp; item instanceof window.constructor) {
          return false;
        }
    
        var _toString = {}.toString;
    
        if (_toString) {
          var name = _toString.call(item);
    
          if (name === '[object Window]' || name === '[object global]' || name === '[object DOMWindow]') {
            return false;
          }
        }
    
        if (typeof item.then === 'function') {
          return true;
        }
      } catch (err) {
        return false;
      }
    
      return false;
    }
    // CONCATENATED MODULE: ./node_modules/zalgo-promise/src/exceptions.js
    var dispatchedErrors = [];
    var possiblyUnhandledPromiseHandlers = [];
    function dispatchPossiblyUnhandledError(err, promise) {
      if (dispatchedErrors.indexOf(err) !== -1) {
        return;
      }
    
      dispatchedErrors.push(err);
      setTimeout(function () {
        if (false) {}
    
        throw err;
      }, 1);
    
      for (var j = 0; j &lt; possiblyUnhandledPromiseHandlers.length; j++) {
        // $FlowFixMe
        possiblyUnhandledPromiseHandlers[j](err, promise);
      }
    }
    function exceptions_onPossiblyUnhandledException(handler) {
      possiblyUnhandledPromiseHandlers.push(handler);
      return {
        cancel: function cancel() {
          possiblyUnhandledPromiseHandlers.splice(possiblyUnhandledPromiseHandlers.indexOf(handler), 1);
        }
      };
    }
    // CONCATENATED MODULE: ./node_modules/zalgo-promise/src/flush.js
    var activeCount = 0;
    var flushPromise;
    
    function flushActive() {
      if (!activeCount &amp;&amp; flushPromise) {
        var promise = flushPromise;
        flushPromise = null;
        promise.resolve();
      }
    }
    
    function startActive() {
      activeCount += 1;
    }
    function endActive() {
      activeCount -= 1;
      flushActive();
    }
    function awaitActive(Zalgo) {
      // eslint-disable-line no-undef
      var promise = flushPromise = flushPromise || new Zalgo();
      flushActive();
      return promise;
    }
    // CONCATENATED MODULE: ./node_modules/zalgo-promise/src/promise.js
    
    
    
    var promise_ZalgoPromise =
    /*#__PURE__*/
    function () {
      function ZalgoPromise(handler) {
        var _this = this;
    
        this.resolved = void 0;
        this.rejected = void 0;
        this.errorHandled = void 0;
        this.value = void 0;
        this.error = void 0;
        this.handlers = void 0;
        this.dispatching = void 0;
        this.stack = void 0;
        this.resolved = false;
        this.rejected = false;
        this.errorHandled = false;
        this.handlers = [];
    
        if (handler) {
          var _result;
    
          var _error;
    
          var resolved = false;
          var rejected = false;
          var isAsync = false;
          startActive();
    
          try {
            handler(function (res) {
              if (isAsync) {
                _this.resolve(res);
              } else {
                resolved = true;
                _result = res;
              }
            }, function (err) {
              if (isAsync) {
                _this.reject(err);
              } else {
                rejected = true;
                _error = err;
              }
            });
          } catch (err) {
            endActive();
            this.reject(err);
            return;
          }
    
          endActive();
          isAsync = true;
    
          if (resolved) {
            // $FlowFixMe
            this.resolve(_result);
          } else if (rejected) {
            this.reject(_error);
          }
        }
    
        if (false) {}
      }
    
      var _proto = ZalgoPromise.prototype;
    
      _proto.resolve = function resolve(result) {
        if (this.resolved || this.rejected) {
          return this;
        }
    
        if (utils_isPromise(result)) {
          throw new Error('Can not resolve promise with another promise');
        }
    
        this.resolved = true;
        this.value = result;
        this.dispatch();
        return this;
      };
    
      _proto.reject = function reject(error) {
        var _this2 = this;
    
        if (this.resolved || this.rejected) {
          return this;
        }
    
        if (utils_isPromise(error)) {
          throw new Error('Can not reject promise with another promise');
        }
    
        if (!error) {
          // $FlowFixMe
          var _err = error &amp;&amp; typeof error.toString === 'function' ? error.toString() : Object.prototype.toString.call(error);
    
          error = new Error("Expected reject to be called with Error, got " + _err);
        }
    
        this.rejected = true;
        this.error = error;
    
        if (!this.errorHandled) {
          setTimeout(function () {
            if (!_this2.errorHandled) {
              dispatchPossiblyUnhandledError(error, _this2);
            }
          }, 1);
        }
    
        this.dispatch();
        return this;
      };
    
      _proto.asyncReject = function asyncReject(error) {
        this.errorHandled = true;
        this.reject(error);
        return this;
      };
    
      _proto.dispatch = function dispatch() {
        var dispatching = this.dispatching,
            resolved = this.resolved,
            rejected = this.rejected,
            handlers = this.handlers;
    
        if (dispatching) {
          return;
        }
    
        if (!resolved &amp;&amp; !rejected) {
          return;
        }
    
      };
    
      _proto.then = function then(onSuccess, onError) {
        if (onSuccess &amp;&amp; typeof onSuccess !== 'function' &amp;&amp; !onSuccess.call) {
          throw new Error('Promise.then expected a function for success handler');
        }
    
        if (onError &amp;&amp; typeof onError !== 'function' &amp;&amp; !onError.call) {
          throw new Error('Promise.then expected a function for error handler');
        }
    
        var promise = new ZalgoPromise();
        this.handlers.push({
          promise: promise,
          onSuccess: onSuccess,
          onError: onError
        });
        this.errorHandled = true;
        this.dispatch();
        return promise;
      };
    
      _proto.catch = function _catch(onError) {
        return this.then(undefined, onError);
      };
    
      _proto.finally = function _finally(onFinally) {
        if (onFinally &amp;&amp; typeof onFinally !== 'function' &amp;&amp; !onFinally.call) {
          throw new Error('Promise.finally expected a function');
        }
    
        return this.then(function (result) {
          return ZalgoPromise.try(onFinally).then(function () {
            return result;
          });
        }, function (err) {
          return ZalgoPromise.try(onFinally).then(function () {
            throw err;
          });
        });
      };
    
      _proto.timeout = function timeout(time, err) {
        var _this3 = this;
    
        if (this.resolved || this.rejected) {
          return this;
        }
    
        var timeout = setTimeout(function () {
          if (_this3.resolved || _this3.rejected) {
            return;
          }
    
          _this3.reject(err || new Error("Promise timed out after " + time + "ms"));
        }, time);
        return this.then(function (result) {
          clearTimeout(timeout);
          return result;
        });
      } // $FlowFixMe
      ;
    
      _proto.toPromise = function toPromise() {
        // $FlowFixMe
        if (typeof Promise === 'undefined') {
          throw new TypeError("Could not find Promise");
        } // $FlowFixMe
    
    
        return Promise.resolve(this); // eslint-disable-line compat/compat
      };
    
      ZalgoPromise.resolve = function resolve(value) {
        if (value instanceof ZalgoPromise) {
          return value;
        }
    
        if (utils_isPromise(value)) {
          // $FlowFixMe
          return new ZalgoPromise(function (resolve, reject) {
            return value.then(resolve, reject);
          });
        }
    
        return new ZalgoPromise().resolve(value);
      };
    
      ZalgoPromise.reject = function reject(error) {
        return new ZalgoPromise().reject(error);
      };
    
      ZalgoPromise.asyncReject = function asyncReject(error) {
        return new ZalgoPromise().asyncReject(error);
      };
    
      ZalgoPromise.all = function all(promises) {
        // eslint-disable-line no-undef
        var promise = new ZalgoPromise();
        var count = promises.length;
        var results = [];
    
        if (!count) {
          promise.resolve(results);
          return promise;
        }
    
        var chain = function chain(i, firstPromise, secondPromise) {
          return firstPromise.then(function (res) {
            results[i] = res;
            count -= 1;
    
            if (count === 0) {
              promise.resolve(results);
            }
          }, function (err) {
            secondPromise.reject(err);
          });
        };
    
        for (var i = 0; i &lt; promises.length; i++) {
          var prom = promises[i];
    
          if (prom instanceof ZalgoPromise) {
            if (prom.resolved) {
              results[i] = prom.value;
              count -= 1;
              continue;
            }
          } else if (!utils_isPromise(prom)) {
            results[i] = prom;
            count -= 1;
            continue;
          }
    
          chain(i, ZalgoPromise.resolve(prom), promise);
        }
    
        if (count === 0) {
          promise.resolve(results);
        }
    
        return promise;
      };
    
      ZalgoPromise.hash = function hash(promises) {
        // eslint-disable-line no-undef
        var result = {};
        return ZalgoPromise.all(Object.keys(promises).map(function (key) {
          return ZalgoPromise.resolve(promises[key]).then(function (value) {
            result[key] = value;
          });
        })).then(function () {
          return result;
        });
      };
    
      ZalgoPromise.map = function map(items, method) {
        // $FlowFixMe
        return ZalgoPromise.all(items.map(method));
      };
    
      ZalgoPromise.onPossiblyUnhandledException = function onPossiblyUnhandledException(handler) {
        return exceptions_onPossiblyUnhandledException(handler);
      };
    
      ZalgoPromise.try = function _try(method, context, args) {
        if (method &amp;&amp; typeof method !== 'function' &amp;&amp; !method.call) {
          throw new Error('Promise.try expected a function');
        }
    
        var result;
        startActive();
    
        try {
          // $FlowFixMe
          result = method.apply(context, args || []);
        } catch (err) {
          endActive();
          return ZalgoPromise.reject(err);
        }
    
        endActive();
        return ZalgoPromise.resolve(result);
      };
    
      ZalgoPromise.delay = function delay(_delay) {
        return new ZalgoPromise(function (resolve) {
          setTimeout(resolve, _delay);
        });
      };
    
      ZalgoPromise.isPromise = function isPromise(value) {
        if (value &amp;&amp; value instanceof ZalgoPromise) {
          return true;
        }
    
        return utils_isPromise(value);
      };
    
      ZalgoPromise.flush = function flush() {
        return awaitActive(ZalgoPromise);
      };
    
      return ZalgoPromise;
    }();
    // CONCATENATED MODULE: ./node_modules/zalgo-promise/src/index.js
    /* concated harmony reexport ZalgoPromise */__webpack_require__.d(__webpack_exports__, "a", function() { return promise_ZalgoPromise; });
    
    
    /***/ }),
    /* 3 */
    /***/ (function(module, __webpack_exports__, __webpack_require__) {
    
    "use strict";
    
    // EXTERNAL MODULE: ./src/lib/device.js
    var device = __webpack_require__(21);
    
    // EXTERNAL MODULE: ./src/lib/util.js
    var util = __webpack_require__(12);
    
    // EXTERNAL MODULE: ./node_modules/post-robot/src/index.js + 12 modules
    var src = __webpack_require__(13);
    
    // EXTERNAL MODULE: ./node_modules/beaver-logger/client/index.js + 8 modules
    var client = __webpack_require__(5);
    
    // EXTERNAL MODULE: ./node_modules/cross-domain-utils/src/index.js + 4 modules
    var cross_domain_utils_src = __webpack_require__(7);
    
    // EXTERNAL MODULE: ./src/config/index.js + 1 modules
    var config = __webpack_require__(4);
    
    // EXTERNAL MODULE: ./src/constants/index.js + 7 modules
    var constants = __webpack_require__(0);
    
    // EXTERNAL MODULE: ./src/lib/session.js
    var session = __webpack_require__(19);
    
    // CONCATENATED MODULE: ./src/lib/proxy.js
    
    
    
    
    function proxyMethod(name, win, originalMethod) {
      if (win &amp;&amp; Object(cross_domain_utils_src["h" /* getDomain */])() === config["a" /* config */].paypalDomain &amp;&amp; !Object(cross_domain_utils_src["v" /* isSameDomain */])(win)) {
        if (win) {
          Object(src["send"])(win, "proxy_" + name, {
            originalMethod: originalMethod
          }).catch(util["j" /* noop */]);
        }
    
        return originalMethod;
      }
    
      var methods = [];
      Object(src["on"])("proxy_" + name, {
        domain: config["a" /* config */].paypal_domain_regex
      }, function (_ref) {
        var data = _ref.data;
        methods.push(data.originalMethod);
      });
      return function postMessageProxy() {
        var _arguments = arguments,
            _this = this;
    
        methods = methods.filter(function (method) {
          return !Object(cross_domain_utils_src["z" /* isWindowClosed */])(method.source);
        });
    
        if (methods.length) {
          return methods[methods.length - 1].apply(this, arguments).catch(function () {
            return originalMethod.apply(_this, _arguments);
          });
        }
    
        return originalMethod.apply(this, arguments);
      };
    }
    // EXTERNAL MODULE: ./src/lib/dom.js
    var dom = __webpack_require__(24);
    
    // EXTERNAL MODULE: ./src/lib/security.js
    var security = __webpack_require__(26);
    
    // CONCATENATED MODULE: ./src/lib/logger.js
    
    
    
    
    
    
    
    
    
    
    
    function getRefererDomain() {
      return window.xchild &amp;&amp; window.xchild.getParentDomain ? window.xchild.getParentDomain() : window.location.host;
    }
    
    var setupProxyLogTransport = Object(util["k" /* once */])(function () {
      Object(client["o" /* setTransport */])(proxyMethod('log', Object(cross_domain_utils_src["n" /* getParent */])(window), Object(client["i" /* getTransport */])()));
    });
    
    function getToken() {
      if (window.root &amp;&amp; window.root.token) {
        return window.root.token;
      }
    
      if (Object(security["b" /* isPayPalDomain */])()) {
        var queryToken = Object(dom["f" /* getQueryParam */])('token');
    
        if (queryToken) {
          return queryToken;
        }
      }
    }
    
    function initLogger() {
      setupProxyLogTransport();
      Object(client["c" /* addPayloadBuilder */])(function () {
        return {
          referer: getRefererDomain(),
          host: window.location.host,
          path: window.location.pathname,
          env: config["a" /* config */].env,
          country: config["a" /* config */].locale.country,
          lang: config["a" /* config */].locale.lang,
          uid: Object(session["c" /* getSessionID */])(),
          ver: "4.0.309"
        };
      });
      Object(client["a" /* addHeaderBuilder */])(function () {
        return {
          'x-app-name': 'checkoutjs'
        };
      });
      Object(client["b" /* addMetaBuilder */])(function () {
        return {
          state: config["a" /* config */].state
        };
      });
      Object(client["d" /* addTrackingBuilder */])(function (payload) {
        var _ref;
    
        if (payload === void 0) {
          payload = {};
        }
    
        var sessionID = Object(session["c" /* getSessionID */])();
        var paymentToken = getToken();
        var buttonSessionID = payload[constants["u" /* FPTI */].KEY.BUTTON_SESSION_UID] || Object(session["a" /* getButtonSessionID */])();
        var contextType;
        var contextID;
    
        if (paymentToken) {
          contextType = constants["u" /* FPTI */].CONTEXT_TYPE[constants["B" /* PAYMENT_TYPE */].EC_TOKEN];
          contextID = paymentToken;
        } else if (buttonSessionID) {
          contextType = constants["u" /* FPTI */].CONTEXT_TYPE.BUTTON_SESSION_ID;
          contextID = buttonSessionID;
        } else {
          contextType = payload[constants["u" /* FPTI */].KEY.CONTEXT_TYPE];
          contextID = payload[constants["u" /* FPTI */].KEY.CONTEXT_ID];
        }
    
        return _ref = {}, _ref[constants["u" /* FPTI */].KEY.FEED] = constants["u" /* FPTI */].FEED.CHECKOUTJS, _ref[constants["u" /* FPTI */].KEY.DATA_SOURCE] = constants["u" /* FPTI */].DATA_SOURCE.CHECKOUT, _ref[constants["u" /* FPTI */].KEY.CONTEXT_TYPE] = contextType, _ref[constants["u" /* FPTI */].KEY.CONTEXT_ID] = contextID, _ref[constants["u" /* FPTI */].KEY.SELLER_ID] = config["a" /* config */].merchantID, _ref[constants["u" /* FPTI */].KEY.SESSION_UID] = sessionID, _ref[constants["u" /* FPTI */].KEY.BUTTON_SESSION_UID] = buttonSessionID, _ref[constants["u" /* FPTI */].KEY.VERSION] = config["a" /* config */].version, _ref[constants["u" /* FPTI */].KEY.TOKEN] = paymentToken, _ref[constants["u" /* FPTI */].KEY.REFERER] = getRefererDomain(), _ref;
      });
      var prefix = 'ppxo';
    
      if (window.location.protocol !== cross_domain_utils_src["a" /* PROTOCOL */].FILE) {
        Object(client["l" /* init */])({
          uri: config["a" /* config */].loggerUrl,
          heartbeat: false,
          logPerformance: false,
          prefix: prefix,
          logLevel: "warn"
        });
      }
    }
    function setLogLevel(logLevel) {
      if (client["m" /* logLevels */].indexOf(logLevel) === -1) {
        throw new Error("Invalid logLevel: " + logLevel);
      }
    
      config["a" /* config */].logLevel = logLevel;
      client["e" /* config */].logLevel = logLevel;
      src["CONFIG"].LOG_LEVEL = logLevel;
      window.LOG_LEVEL = logLevel;
    }
    // CONCATENATED MODULE: ./src/lib/eligibility.js
    
    
    
    
    var bowserCache = {};
    
    function getBowser() {
      var userAgent = Object(device["a" /* getUserAgent */])();
    
      if (bowserCache[userAgent]) {
        return bowserCache[userAgent];
      }
    
      delete __webpack_require__.c[/*require.resolve*/(42)];
    
      var bowser = __webpack_require__(42);
    
      bowserCache[userAgent] = bowser;
      return bowser;
    }
    
    function getBrowser() {
      var bowser = getBowser();
    
      for (var _i2 = 0, _Object$keys2 = Object.keys(config["a" /* config */].SUPPORTED_BROWSERS); _i2 &lt; _Object$keys2.length; _i2++) {
        var browser = _Object$keys2[_i2];
    
        if (bowser[browser]) {
          return {
            browser: browser,
            version: bowser.version
          };
        }
      }
    
      return {};
    }
    
    function isBrowserEligible() {
      if (Object(device["e" /* isIEIntranet */])()) {
        return false;
      }
    
      var bowser = getBowser();
    
      var _getBrowser = getBrowser(),
          browser = _getBrowser.browser,
          version = _getBrowser.version;
    
      if (browser &amp;&amp; version &amp;&amp; bowser.compareVersions([version, config["a" /* config */].SUPPORTED_BROWSERS[browser]]) === -1) {
        return false;
      }
    
      return true;
    }
    
    var eligibilityResults = {};
    function isEligible() {
      if (Object(device["e" /* isIEIntranet */])()) {
        return false;
      }
    
      var userAgent = window.navigator.userAgent;
    
      if (userAgent &amp;&amp; eligibilityResults.hasOwnProperty(userAgent)) {
        return eligibilityResults[userAgent];
      }
    
      var result = isBrowserEligible();
      eligibilityResults[userAgent] = result;
      return result;
    }
    var checkRecognizedBrowser = Object(util["k" /* once */])(function (state) {
      var _getBrowser2 = getBrowser(),
          browser = _getBrowser2.browser;
    
      if (!browser) {
        var _getBowser = getBowser(),
            name = _getBowser.name,
            version = _getBowser.version,
            mobile = _getBowser.mobile,
            android = _getBowser.android,
            ios = _getBowser.ios;
    
        Object(client["k" /* info */])("unrecognized_browser_" + state, {
          name: name,
          version: version,
          mobile: mobile,
          android: android,
          ios: ios
        });
        Object(client["h" /* flush */])();
      }
    });
    // CONCATENATED MODULE: ./src/lib/errors.js
    
    
    
    function logWarn(err) {
      if (window.console) {
        if (window.console.warn) {
          return window.console.warn(err);
        }
    
        if (window.console.log) {
          return window.console.log(err);
        }
      }
    }
    
    function checkForCommonErrors() {
      if (JSON.stringify([]) !== '[]') {
        // $FlowFixMe
        if (Array.prototype.toJSON) {
          logWarn("Custom Array.prototype.toJSON is causing incorrect json serialization of arrays. This is likely to cause issues. Probable cause is Prototype.js");
        } else {
          logWarn("JSON.stringify is doing incorrect serialization of arrays. This is likely to cause issues.");
        }
    
        Object(client["q" /* warn */])("json_stringify_array_broken");
      }
    
      if (JSON.stringify({}) !== '{}') {
        logWarn("JSON.stringify is doing incorrect serialization of objects. This is likely to cause issues.");
        Object(client["q" /* warn */])("json_stringify_object_broken");
      }
    
      if (Object(device["e" /* isIEIntranet */])()) {
        Object(client["q" /* warn */])("ie_intranet_mode");
      }
    
      if (Object(device["c" /* isIE */])() &amp;&amp; !Object(device["d" /* isIECompHeader */])()) {
        Object(client["q" /* warn */])("ie_meta_compatibility_header_missing", {
          message: "Drop tag: &lt;meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\"&gt;"
        });
      } // eslint-disable-next-line no-unused-vars
    
    
      function foo(bar, baz, zomg) {// pass;
      }
    
      if (foo.bind({
        a: 1
      }).length !== 3) {
        Object(client["q" /* warn */])("function_bind_arrity_overwritten");
      }
    
      if (window.opener &amp;&amp; window.parent !== window) {
        Object(client["q" /* warn */])("window_has_opener_and_parent");
      }
    
      if (window.name &amp;&amp; window.name.indexOf('__prerender') === 0) {
        Object(client["q" /* warn */])("prerender_running_checkoutjs");
      }
    
      var context = {};
    
      function returnContext() {
        return this;
      }
    
      if (returnContext.bind(context)() !== context) {
        Object(client["q" /* warn */])("function_bind_broken");
      }
    
      if (window.Window &amp;&amp; window.constructor &amp;&amp; window.Window !== window.constructor) {
        Object(client["q" /* warn */])("window_constructor_does_not_match_window");
      } // $FlowFixMe
    
    
      if (Object.assign &amp;&amp; JSON.stringify({
        a: 1,
        b: 2,
        c: 3
      }) !== JSON.stringify({
        a: 1,
        b: 2,
        c: 3
      })) {
        // eslint-disable-line no-self-compare, compat/compat
        Object(client["q" /* warn */])("object_assign_broken");
      }
    }
    // EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/extends.js
    var esm_extends = __webpack_require__(11);
    
    // EXTERNAL MODULE: ./node_modules/zalgo-promise/src/index.js + 4 modules
    var zalgo_promise_src = __webpack_require__(2);
    
    // CONCATENATED MODULE: ./src/lib/http.js
    
    
    
    var HEADERS = {
      CONTENT_TYPE: 'content-type',
      ACCEPT: 'accept'
    };
    var headerBuilders = [];
    var corrids = [];
    Object(client["c" /* addPayloadBuilder */])(function () {
      return {
        prev_corr_ids: corrids.join(',')
      };
    });
    
    function parseHeaders(rawHeaders) {
      if (rawHeaders === void 0) {
        rawHeaders = '';
      }
    
      var result = {};
    
      for (var _i2 = 0, _rawHeaders$trim$spli2 = rawHeaders.trim().split('\n'); _i2 &lt; _rawHeaders$trim$spli2.length; _i2++) {
        var line = _rawHeaders$trim$spli2[_i2];
    
        var _line$split = line.split(':'),
            _key = _line$split[0],
            values = _line$split.slice(1);
    
        result[_key.toLowerCase()] = values.join(':').trim();
      }
    
      return result;
    }
    
    function request(_ref) {
      var url = _ref.url,
          _ref$method = _ref.method,
          method = _ref$method === void 0 ? 'get' : _ref$method,
          _ref$headers = _ref.headers,
          headers = _ref$headers === void 0 ? {} : _ref$headers,
          json = _ref.json,
          data = _ref.data,
          body = _ref.body,
          _ref$win = _ref.win,
          win = _ref$win === void 0 ? window : _ref$win,
          _ref$timeout = _ref.timeout,
          timeout = _ref$timeout === void 0 ? 0 : _ref$timeout;
    
      if (url === '/demo/checkout/api/braintree/client-token/') {
        // $FlowFixMe
        return zalgo_promise_src["a" /* ZalgoPromise */].resolve('eyJ2ZXJzaW9uIjoyLCJhdXRob3JpemF0aW9uRmluZ2VycHJpbnQiOiJjMDFhZmRkM2Y1OTJmNWVhNTNlMzE5MWQwYmIyMWVjYjM5NzNlZGM1MzkwNDZiMjJmNTA2ODEyNzIzZmRlMTJifGNsaWVudF9pZD1jbGllbnRfaWQkc2FuZGJveCQ0ZHByYmZjNnBoNTk1Y2NqXHUwMDI2Y3JlYXRlZF9hdD0yMDE3LTA0LTI2VDIzOjI2OjU5Ljg3OTA3ODYwNiswMDAwXHUwMDI2bWVyY2hhbnRfaWQ9M3cydHR2d2QyNDY1NDhoZCIsImNvbmZpZ1VybCI6Imh0dHBzOi8vYXBpLnNhbmRib3guYnJhaW50cmVlZ2F0ZXdheS5jb206NDQzL21lcmNoYW50cy8zdzJ0dHZ3ZDI0NjU0OGhkL2NsaWVudF9hcGkvdjEvY29uZmlndXJhdGlvbiIsImNoYWxsZW5nZXMiOltdLCJlbnZpcm9ubWVudCI6InNhbmRib3giLCJjbGllbnRBcGlVcmwiOiJodHRwczovL2FwaS5zYW5kYm94LmJyYWludHJlZWdhdGV3YXkuY29tOjQ0My9tZXJjaGFudHMvM3cydHR2d2QyNDY1NDhoZC9jbGllbnRfYXBpIiwiYXNzZXRzVXJsIjoiaHR0cHM6Ly9hc3NldHMuYnJhaW50cmVlZ2F0ZXdheS5jb20iLCJhdXRoVXJsIjoiaHR0cHM6Ly9hdXRoLnZlbm1vLnNhbmRib3guYnJhaW50cmVlZ2F0ZXdheS5jb20iLCJhbmFseXRpY3MiOnsidXJsIjoiaHR0cHM6Ly9jbGllbnQtYW5hbHl0aWNzLnNhbmRib3guYnJhaW50cmVlZ2F0ZXdheS5jb20vM3cydHR2d2QyNDY1NDhoZCJ9LCJ0aHJlZURTZWN1cmVFbmFibGVkIjpmYWxzZSwicGF5cGFsRW5hYmxlZCI6dHJ1ZSwicGF5cGFsIjp7ImRpc3BsYXlOYW1lIjoiYmFyY28uMDMtZmFjaWxpdGF0b3JAZ21haWwuY29tIiwiY2xpZW50SWQiOiJBV3VZdnFnMGtaN2Y5S0V4TVpqZU53T3RjQV8yZVhnOWpMZy1QSnBGX0pnYk44M0YyVml5aEdnV2JCNDg4RGU3MFpucGRBZEI2TUNqekNqSyIsInByaXZhY3lVcmwiOiJodHRwczovL2V4YW1wbGUuY29tIiwidXNlckFncmVlbWVudFVybCI6Imh0dHBzOi8vZXhhbXBsZS5jb20iLCJiYXNlVXJsIjoiaHR0cHM6Ly9hc3NldHMuYnJhaW50cmVlZ2F0ZXdheS5jb20iLCJhc3NldHNVcmwiOiJodHRwczovL2NoZWNrb3V0LnBheXBhbC5jb20iLCJkaXJlY3RCYXNlVXJsIjpudWxsLCJhbGxvd0h0dHAiOnRydWUsImVudmlyb25tZW50Tm9OZXR3b3JrIjpmYWxzZSwiZW52aXJvbm1lbnQiOiJvZmZsaW5lIiwidW52ZXR0ZWRNZXJjaGFudCI6ZmFsc2UsImJyYWludHJlZUNsaWVudElkIjoibWFzdGVyY2xpZW50MyIsImJpbGxpbmdBZ3JlZW1lbnRzRW5hYmxlZCI6dHJ1ZSwibWVyY2hhbnRBY2NvdW50SWQiOiJVU0QiLCJjdXJyZW5jeUlzb0NvZGUiOiJVU0QifSwiY29pbmJhc2VFbmFibGVkIjpmYWxzZSwibWVyY2hhbnRJZCI6IjN3MnR0dndkMjQ2NTQ4aGQiLCJ2ZW5tbyI6Im9mZiJ9');
      }
    
      return new zalgo_promise_src["a" /* ZalgoPromise */](function (resolve, reject) {
        if (json &amp;&amp; data || json &amp;&amp; body || data &amp;&amp; json) {
          throw new Error("Only options.json or options.data or options.body should be passed");
        }
    
        var normalizedHeaders = {};
    
        for (var _i4 = 0, _Object$keys2 = Object.keys(headers); _i4 &lt; _Object$keys2.length; _i4++) {
          var _key2 = _Object$keys2[_i4];
          normalizedHeaders[_key2.toLowerCase()] = headers[_key2];
        }
    
        if (json) {
          normalizedHeaders[HEADERS.CONTENT_TYPE] = normalizedHeaders[HEADERS.CONTENT_TYPE] || 'application/json';
        } else if (data || body) {
          normalizedHeaders[HEADERS.CONTENT_TYPE] = normalizedHeaders[HEADERS.CONTENT_TYPE] || 'application/x-www-form-urlencoded; charset=utf-8';
        }
    
        normalizedHeaders[HEADERS.ACCEPT] = normalizedHeaders[HEADERS.ACCEPT] || 'application/json';
    
        for (var _i6 = 0; _i6 &lt; headerBuilders.length; _i6++) {
          var headerBuilder = headerBuilders[_i6];
          var builtHeaders = headerBuilder();
    
          for (var _i8 = 0, _Object$keys4 = Object.keys(builtHeaders); _i8 &lt; _Object$keys4.length; _i8++) {
            var _key3 = _Object$keys4[_i8];
            normalizedHeaders[_key3.toLowerCase()] = builtHeaders[_key3];
          }
        }
    
        var xhr = new win.XMLHttpRequest();
        xhr.addEventListener('load', function xhrLoad() {
          var responseHeaders = parseHeaders(this.getAllResponseHeaders());
          var corrID = responseHeaders['paypal-debug-id'] || 'unknown';
    
          if (responseHeaders['paypal-debug-id']) {
            corrids.push(responseHeaders['paypal-debug-id']);
          }
    
          if (!this.status) {
            return reject(new Error("Request to " + method.toLowerCase() + " " + url + " failed: no response status code. Correlation id: " + corrID));
          }
    
          var contentType = responseHeaders['content-type'];
          var isJSON = contentType &amp;&amp; (contentType.indexOf('application/json') === 0 || contentType.indexOf('text/json') === 0);
          var res = this.responseText;
    
          try {
            res = JSON.parse(this.responseText);
          } catch (err) {
            if (isJSON) {
              return reject(new Error("Invalid json: " + this.responseText + ". Correlation id: " + corrID));
            }
          }
    
          if (this.status &gt;= 400) {
            var message = "Request to " + method.toLowerCase() + " " + url + " failed with " + this.status + " error. Correlation id: " + corrID;
    
            if (res) {
              if (typeof res === 'object' &amp;&amp; res !== null) {
                res = JSON.stringify(res, null, 4);
              }
    
              message = message + "\n\n" + res + "\n";
            }
    
            return reject(new Error(message));
          }
    
          return resolve(res);
        }, false);
        xhr.addEventListener('error', function xhrError(evt) {
          var corrID = this.getResponseHeader('paypal-debug-id');
          reject(new Error("Request to " + method.toLowerCase() + " " + url + " failed: " + evt.toString() + ". Correlation id: " + corrID));
        }, false);
        xhr.open(method, url, true);
    
        for (var _key4 in normalizedHeaders) {
          if (normalizedHeaders.hasOwnProperty(_key4)) {
            xhr.setRequestHeader(_key4, normalizedHeaders[_key4]);
          }
        }
    
        if (json) {
          body = JSON.stringify(json);
        } else if (data) {
          body = Object.keys(data).map(function (key) {
            return encodeURIComponent(key) + "=" + (data ? encodeURIComponent(data[key]) : '');
          }).join('&amp;');
        }
    
        xhr.timeout = timeout;
    
        xhr.ontimeout = function xhrTimeout() {
          reject(new Error("Request to " + method.toLowerCase() + " " + url + " has timed out"));
        };
    
        xhr.send(body);
      });
    }
    
    request.get = function (url, options) {
      if (options === void 0) {
        options = {};
      }
    
      return request(Object(esm_extends["a" /* default */])({
        method: 'get',
        url: url
      }, options));
    };
    
    request.post = function (url, data, options) {
      if (options === void 0) {
        options = {};
      }
    
      return request(Object(esm_extends["a" /* default */])({
        method: 'post',
        url: url,
        data: data
      }, options));
    };
    
    request.addHeaderBuilder = function (method) {
      headerBuilders.push(method);
    };
    // EXTERNAL MODULE: ./src/lib/beacon.js
    var beacon = __webpack_require__(29);
    
    // CONCATENATED MODULE: ./src/lib/throttle.js
    
    
    