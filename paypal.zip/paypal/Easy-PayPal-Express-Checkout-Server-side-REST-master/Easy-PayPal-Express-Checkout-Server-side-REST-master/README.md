# Easy-PayPal-Express-Checkout-Server-side-REST
Une classe PHP permettant de mettre facilement en place le système de paiement PayPal Express Checkout Server-side REST
