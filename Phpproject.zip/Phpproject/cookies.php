<?php

$amazon_key = "AmazonProduct";
$amazon_product = "MacBook Air";
setcookie($amazon_key, $amazon_product, time(), + (86400 * 30), "/");


?>
<!DOCTYPE HTML>
<html>
<body>
 <?php
    if (isset($_COOKIE["AmazonProduct"])){
    echo $_COOKIE["AmazonProduct"];
    } else {
        echo "Sorry, no cookies";
    }
 ?>
</body>
</html>