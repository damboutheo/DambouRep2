<?php
    /*$name = "Joe Santos";
    $sentence = "Hey i'm {$name} , i got my Mac Book pro 13";
    $sentence = str_shuffle($sentence);*/
include("discrimant.php");
$solution = equat(2,5,1);
?>
<!DOCTYPE HTML>
<html>
<body>
  <h1><?php 
    echo $solution;
   // echo ($sentence);
   echo readfile("theo.txt");
    
   ?>
   </h1> 
</body>
</html>