<?php
function myName($name){
    echo "<h4>my name is {$name}</h4>";
};

function adding($a, $b){
    $total = $a + $b;
    return "The total number is : {$total}";
}
$newnumber= adding(7,9);
?>
<!DOCTYPE html>
<html>
<body>
    <?php echo myName("joe");?>
    <?php echo $newnumber;?>
    <?php myName("dario");?>
    <?php myName("benedetto");?>
</body>
</html>