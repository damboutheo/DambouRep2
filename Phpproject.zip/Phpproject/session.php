<?php
session_start();
$_SESSION["amazon_key"] = "MacBook_Air";
//$_SESSION["amazon_product"] = "MacBook_Air";

?>
<!DOCTYPE HTML>
<html>
<body>
 <?php
    if (isset($_SESSION["MacBook_Air"])){
    echo $_SESSION["MacBook_Air"];
    } else {
        echo "Sorry, no session for that user";
    }
 ?>
</body>
</html>