<?php
class Car {
    public $doors = 4;
    public function __construct($name){
        $this->doors=2;
        $this->name = $name;
 }
 public function printName(){
     echo $this->name;
 }
}
 $honda = new Car("Civic");
 $honda->printName();
 echo "<pre>". var_dump($honda)."</pre>";
 /*echo $honda->doors;
 echo $honda->name;*/
?>

<!DOCTYPE HTML>
<html>
<body>
 <?php
   
 ?>
</body>
</html>