<?php
    function equat($a, $b, $c){
        $delta = ($b*$b) - (4 * $a * $c);
        if ( $delta > 0){
            $x1 = (-$b + sqrt($delta))/(2*$a);
            $x2 = (-$b - sqrt($delta))/(2*$a);
        return "l'equation admet deux solutions: x1 = {$x1} et x2 = {$x2}";
    } elseif($delta=0){
        $x= -$b/(2*$a);
        return "l'equation n'admet qu'une solution: x = {$x}";
    }else {
        return "l'équation n'admet pas de solution réelle";
    }
}
    $solution = equat(1,6,1);
?>
<!DOCTYPE html>
<html>
<body>
    
    <?php echo $solution?>
    
</body>
</html>
