<?php
for ($i=0; $i<11 ; $i++){
    echo $i;
}
?>
<!DOCTYPE html>
<html>
<body>
    
</body>
</html>