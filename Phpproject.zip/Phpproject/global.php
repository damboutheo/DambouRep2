<?php
$car = "Honda civic";
$name = "joe";

function echoCar(){
    //global $car;
    echo $GLOBALS["car"];
    echo $GLOBALS["name"];
};

echoCar();

?>


<!DOCTYPE HTML>
<html>
<body>
  <h1><?php 
       
   ?>
   </h1> 
</body>
</html>