<?php
if (isset(S_GET['username'])){
    echo "<h1>username: {S_GET['username']}</h1>";
echo "<h1>lastname: {S_GET['lastname']}</h1>";
echo "<h1>age: {S_GET['age']}</h1>";
}

if (isset(S_POST["username"])){
    echo S_POST["username"];
}
?>


<!DOCTYPE HTML>
<html>
<body>
  <form action="getpost.php" method="POST">
  <label for="username">Username</label>
  <input type="text" name="username">
  <button type="submit">Send</button>
  </form>
</body>
</html>