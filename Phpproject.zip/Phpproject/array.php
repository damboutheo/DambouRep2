<?php
$names = array("Joe santos", "John Doe", "Jane Doe");
$name = ["Joe santos", "John Doe", "Jane Doe"];
echo $name[0];
echo var_dump($name);
?>
<!DOCTYPE html>
<html>
<body>
    
</body>
</html>