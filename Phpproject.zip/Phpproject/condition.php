<?php
$name = "joe";
if (24>20 && $name == "joes"){
    echo "Yes is greater";

} else{
    echo "It is lesser";
}

?>
<!DOCTYPE html>
<html>
<body>
    
</body>
</html>