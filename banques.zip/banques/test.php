<?php

$con=mysqli_connect("127.0.0.1","root","","banque");


if(mysqli_connect_errno($con))

{

echo "Connection Error: ".mysqli_connect_error();

}


$qry="SELECT * FROM depot WHERE numcompte = '745896321'";

$result =mysqli_query($con,$qry);

if (!$result) {
    echo("Error description: " . mysqli_error($con));
    exit();
}

print "<h5>Travel: Category & Activity Data</h5>";

echo "<table border='1'>

<tr>
<th>ID</th>
<th>Account number</th>
<th>Deposit amount ($)</th>
<th>Description</th>
<th>Deposit date</th>
</tr>";


// declare variable to store the price addition in the while loop
$total_price = 0;

while($rowval = mysqli_fetch_array($result))

  {

  echo "<tr>";
  
//   echo "<td></td>";

  echo "<td>" . $rowval['id'] . "</td>";

  echo "<td>" . $rowval['numcompte'] . "</td>";
  
    echo "<td>" . $rowval['montantdepot'] . "</td>";

  echo "<td>" . $rowval['libelle'] . "</td>";
  
  echo "<td>" . $rowval['date_mes'] . "</td>";

  echo "</tr>";


// add the price to the total
   $total_price += $rowval['montantdepot'];

}

// add a last row to display only the total price in the last column


// closeing table tag
echo "</table>";
echo "<tr><td></td><td></td><td></td><td></td><td></td><td>$total_price</td><tr>";
mysqli_close($con);

?>