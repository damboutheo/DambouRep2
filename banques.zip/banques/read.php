<?php
require("database.php");
//Create new depot

 if (isset($_GET["show"]) && isset($_GET["id"])) {
    $id = $_GET["id"];
    try{
      $statement = $pdo->prepare(
        'SELECT * FROM depot WHERE id = :id;'
      );
      $statement->execute(["id" => $id]);

      $results = $statement->fetchAll(PDO::FETCH_OBJ);
    //  echo "Read from table depot</br>";
    }catch (PDOException $e) {
        echo "<h4 style='color: red;'>".$e->getMessage(). "</h4>";
}
} else {
   echo "<script>location.href='home.php' </script>";
   die();
  }


 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=EB+Garamond&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/32597ef393.js" crossorigin="anonymous"></script>
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

		<title></title>
  </head>
  <nav class="navbar navbar-inverse" style="height: 100px">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="nomMenu">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="index.html"><img src="IMG/UBA-Logo.svg" alt="LOGO" style="height: 35px"></a>
				</div>
				<div class="collapse navbar-collapse" id="monMenu">
					<ul class="nav navbar-nav" style="margin-top: 30px">
						<li style="font-size:20px"><a href="index.html"><i class="fas fa-home"></i></a></li>
						<li><a href="contact.html">CONTACT</a></li>
					</ul>
					<ul class="navbar-nav navbar-right" style="margin-top: 40px">
						<li><a href="create.php"><span class="glyphicon glyphicon-log-in"></span> ADMINISTRATOR</a></li>
					</ul>
				
				</div>
			</div>

		</nav>
  <body>
    <table border="1" style="width:100%" class="table table-striped table-dark">
        <tr>
            <!-- <th>id</th> -->
            <th>Account number</th>
            <th>Deposit amount</th>
            <th>Description</th>
            <th>Deposit date</th>
            <th>Edit</th>
            <!-- <th>delete</th> -->
        </tr>
        <?php foreach ($results as $user) { ?>
          <tr>
              <!-- <td><?php echo $user->id;?></td> -->
              <td><?php echo $user->numcompte;?></td>
              <td><?php echo $user->montantdepot;?></td>
              <td><?php echo $user->libelle;?></td>
              <td><?php echo $user->date_mes?></td>
              <td><a href="update.php?id=<?php echo $user->id;?>">Edit</a>
              </td>
              <!-- <td><a href="delete.php?id=<?php echo $user->id;?>" onclick="confirm()">delete</a>
              </td> -->
          </tr>
    
       <?php } ?>
    </table>
       <a href="create.php">Go Back</a>
  </body>
</html>
