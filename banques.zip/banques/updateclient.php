<?php
require('database.php');
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_GET["id"]) && $_POST["_method"] == "PUT") {
  $pseudo = $_POST["pseudo"];
  $mail = $_POST["mail"];
  $numcompte = $_POST["numcompte"];
  $nomprenom = $_POST["nomprenom"];
  $id = $_GET["id"];
  
  $statement = $pdo -> prepare( "UPDATE user SET pseudo = :pseudo, mail = :mail, numcompte = :numcompte, nomprenom = :nomprenom
   WHERE id = :id");
  $statement -> execute(["pseudo"=>$pseudo, "mail"=>$mail, "numcompte"=>$numcompte,"nomprenom"=>$nomprenom, "id"=>$id]);
//   $id = $conn->lastInsertId();
echo "Data updated";
    // if($res){
		
    //     echo "<div class='sucess'>
    //           <h3>The client was successfully updated.</h3>
	//  		 <p>Click <a href='inscription.php'>here</a> to create a new client</p>
	//  		 <a href='home.php'>Go back</a>
    //    </div>";
    // }
}
//Handles get request
if (isset($_GET["id"])) {
  $id = $_GET["id"];
  try {
    $statement = $pdo->prepare(
      'SELECT * FROM user WHERE id=:id;'
    );
    $statement->execute(["id" => $id]);
    $results = $statement->fetchAll(PDO::FETCH_OBJ);
  } catch (PDOException $e) {
      echo "<h4 style='color: red;'>".$e->getMessage(). "</h4>";
  }
}

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://fonts.googleapis.com/css?family=EB+Garamond&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/32597ef393.js" crossorigin="anonymous"></script>
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<link href="style.css" rel="stylesheet" type="text/css" media="screen"/>
		<title></title>
</head>
<body>
<nav class="navbar navbar-inverse">
		  <div class="container-fluid">
		    
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="index.html"><img src="IMG/UBA-Logo.svg" alt="LOGO" style="height: 35px"></a>	
					</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav" style="margin-top: 30px">
						<li style="font-size:20px"><a href="index.html"><i class="fas fa-home"></i></a></li>
					</ul>
					<ul class="navbar-nav navbar-right" style="margin-top: 40px">
						<li style="font-size: 25px"><a href="login.php"> <i class="fas fa-users-cog"></i></a></li>
					</ul>
					<ul class="navbar-nav navbar-right" style="margin-top: 40px">
						<li><a href="connexion.php"><span class="glyphicon glyphicon-log-in"></span> ESPACE CLIENT</a></li>
					</ul>
				</div>
		  </div>
		</nav>

<div class="container-fluid jump">
	<div class="row">

		  <form class="form-group" action="updateclient.php?id=<?php echo $results[0]->id;?>" method="POST">
              <input type="hidden" name="_method" value="PUT" class="form-control">
                <label for="pseudo">Username</label><br>
                <input type="text" name="pseudo" value="<?php echo
                $results[0]->pseudo;?>" class="form-control"><br>
                <label for="mail">mail</label><br>
                <input type="text" name="mail" value="<?php echo
                $results[0]->mail;?>" class="form-control"><br>
                <label for="nomprenom">Full name</label><br>
                <input type="text" name="nomprenom" value="<?php echo
				$results[0]->nomprenom;?>" class="form-control"><br>
				<label for="numcompte">Account number</label><br>
                <input type="text" name="numcompte" value="<?php echo
                $results[0]->numcompte;?>" class="form-control"><br>
                <button type="Submit" name="Save" class="btn btn-info">Edit</button>

		  </form>
		   <a href="client.php?show=all">Retour</a>
</div>
</body>
</html>