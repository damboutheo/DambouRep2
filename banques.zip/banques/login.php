<?php
require('config.php');
session_start();
if (isset($_POST['username'])){
  $username = stripslashes($_REQUEST['username']);
  $username = mysqli_real_escape_string($conn, $username);
  $_SESSION['username'] = $username;
  $password = stripslashes($_REQUEST['password']);
  $password = mysqli_real_escape_string($conn, $password);
    $query = "SELECT * FROM `users` WHERE username='$username' 
  and password='".hash('sha256', $password)."'";
  
  $result = mysqli_query($conn,$query) or die(mysql_error());
  
  if (mysqli_num_rows($result) == 1) {
    $user = mysqli_fetch_assoc($result);
    // vérifier si l'utilisateur est un administrateur ou un utilisateur
    if ($user['type'] == 'admin') {
      header('location:home.php');      
    }else{
      header('location:home.php');
    }
  }else{
    $message = "Le nom d'utilisateur ou le mot de passe est incorrect.";
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://fonts.googleapis.com/css?family=EB+Garamond&display=swap" rel="stylesheet">
  <script src="https://kit.fontawesome.com/32597ef393.js" crossorigin="anonymous"></script>
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="style.css" rel="stylesheet" type="text/css" media="screen"/>

		<title></title>
</head>
<body>
  <nav class="navbar navbar-inverse">
		  <div class="container-fluid">
		    
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="index.html"><img src="IMG/UBA-Logo.svg" alt="LOGO" style="height: 35px"></a>	
					</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav" style="margin-top: 30px">
						<li style="font-size:20px"><a href="index.html"><i class="fas fa-home"></i></a></li>
            <li><a href="contact.html">CONTACT</a></li>
					</ul>
					
					<ul class="navbar-nav navbar-right" style="margin-top: 40px">
						<li><a href="connexion.php"><span class="glyphicon glyphicon-log-in"></span> CLIENT LOGIN</a></li>
					</ul>
				</div>
		  </div>
		</nav>

<div class="container-fluid jump">
    <div class="row">
        <form class="form-group" action="" method="post" name="login">
        <h1 class="box-logo box-title">
        </h1>
        <h1 class="box-title">Administrator login</h1>
        <input type="text" class="form-control" name="username" placeholder="username">
        <input type="password" class="form-control" name="password" placeholder="password">
        <input type="submit" value="Connexion " name="submit" class="btn btn-danger">
        <!-- <p class="box-register">Vous êtes nouveau ici? 
        <a href="register.php">S'inscrire</a>
        </p> -->
        <?php if (! empty($message)) { ?>
            <p class="errorMessage"><?php echo $message; ?></p>
        <?php } ?>
        </form>
    </div>
</div>
</body>
</html>
 