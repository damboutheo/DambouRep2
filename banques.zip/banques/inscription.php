<?php
require('database.php');
//Create new Users
if ($_SERVER['REQUEST_METHOD'] == "POST") {
  $pseudo = $_POST["pseudo"];
  $mail = $_POST["mail"];
  $nomprenom = $_POST["nomprenom"];
  $password = $_POST["password"];
  $numcompte=$_POST["numcompte"];
	try{
  $statement = $pdo -> prepare( "INSERT into `user` (pseudo, mail, nomprenom, password, numcompte)
        VALUES ('$pseudo', '$mail', '$nomprenom' , '".hash('sha256', $password)."', '$numcompte')");
  $statement->execute(['pseudo'=> $pseudo, 'mail'=> $mail, 'nomprenom'=> $nomprenom, 'password' => $password]);
    echo "Insert user: {$nomprenom} {$numcompte}";
    $id = $pdo->lastInsertId();
     echo "<script>location.href='clients.php?show=one&id={$id}' </script>";
  } catch (PDOException $e) {
      echo "<h4 style='color: red;'>".$e->getMessage(). "</h4>";
  }

}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://fonts.googleapis.com/css?family=EB+Garamond&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/32597ef393.js" crossorigin="anonymous"></script>
	<script src="https://kit.fontawesome.com/32597ef393.js" crossorigin="anonymous"></script>
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<link href="style.css" rel="stylesheet" type="text/css" media="screen"/>
		<title></title>
</head>
<body>
<nav class="navbar navbar-inverse">
		  <div class="container-fluid">
		    
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="index.html"><img src="IMG/UBA-Logo.svg" alt="LOGO" style="height: 35px"></a>	
					</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav" style="margin-top: 30px">
						<li style="font-size:20px"><a href="index.html"><i class="fas fa-home"></i></a></li>
					</ul>
					<ul class="navbar-nav navbar-right" style="margin-top: 40px">
						<li style="font-size: 25px"><a href="login.php"> <i class="fas fa-users-cog"></i></a></li>
					</ul>
					<ul class="navbar-nav navbar-right" style="margin-top: 40px">
						<li><a href="connexion.php"><span class="glyphicon glyphicon-log-in"></span> ESPACE CLIENT</a></li>
					</ul>
				</div>
		  </div>
		</nav>

<div class="container-fluid jump">
	<div class="row">

		<form class="form-group" action="" method="post">
		<h1 class="box-logo box-title">
		
		</h1>
			<h2 class="box-title">CREATE A CLIENT</h2>
		<input type="text" class="form-control" name="pseudo" 
		placeholder="Username" required />
		<input type="text" class="form-control" name="mail" 
		placeholder="Email" required />
		<input type="text" class="form-control" name="nomprenom" 
		placeholder="First Name & Last Name" required />
			<input type="password" class="form-control" name="password" 
		placeholder="Password" required />
		<input type="text" class="form-control" name="numcompte" 
		placeholder="Account number" required />
			<button type="submit" name="submit" 
		value="S'inscrire" class="btn btn-danger">SUBMIT<button/>
		
			<!-- <p class="box-register">Déjà inscrit? 
		<a href="login.php">Connectez-vous ici</a></p> -->
		</form>
</div>

</body>
</html>