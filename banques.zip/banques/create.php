<?php
require("database.php");
//Create new Users
if ($_SERVER['REQUEST_METHOD'] == "POST") {
  $numcompte = $_POST["numcompte"];
  $montantdepot = $_POST["montantdepot"];
  $libelle = $_POST["libelle"];
  $date_mes = $_POST["date_mes"];
  try {
    $statement = $pdo->prepare(
      'INSERT INTO depot (numcompte,montantdepot,libelle, date_mes) VALUES
      (:numcompte, :montantdepot, :libelle, :date_mes);'
    );
    $statement->execute(['numcompte'=> $numcompte, 'montantdepot'=> $montantdepot, 'libelle'=> $libelle, 'date_mes' => $date_mes]);
    echo "Insert user: {$numcompte} {$montantdepot}";
    $id = $pdo->lastInsertId();

    echo "<script>location.href='read.php?show=one&id={$id}' </script>";
  } catch (PDOException $e) {
      echo "<h4 style='color: red;'>".$e->getMessage(). "</h4>";
  }

}
 
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="style.css" rel="stylesheet" type="text/css" media="screen"/>

		<title></title>
</head>
  <body>
  <nav class="navbar navbar-default">
		  <div class="container-fluid">
		    
				<div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
				    	<a class="navbar-brand" href="index.html"><img src="IMG/UBA-Logo.svg" alt="LOGO" style="height: 50px"></a>	
					</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav" style="margin-top: 30px">
						<li><a href="index.html">HOME</a></li>
            <li><a href="contact.html">CONTACT</a></li>
					</ul>
					<ul class="navbar-nav navbar-right" style="margin-top: 40px">
						<li style="font-size: 25px"><a href="login.php"> <i class="fas fa-users-cog"></i></a></li>
					</ul>
					<!--<ul class="navbar-nav navbar-right" style="margin-top: 40px">
						<li><a href="inscription.php"><span class="glyphicon glyphicon-log-in"></span> CREER UN CLIENT</a></li>
					</ul>-->
				</div>
		  </div>
		</nav>
    <h1 style="text-align:center">MAKE A DEPOSIT</h1>
    <div class="container-fluid jump">
      <div class="row">
        <form class="creating" action="create.php" method="POST">
          <div class="form-group">
              <label for="numcompte">Account number</label><br>
              <input type="text" name="numcompte" placeholder="Account number" value="" class="form-control"><br>
              <label for="montantdepot">Deposit amount</label><br>
              <input type="text" name="montantdepot" placeholder="Deposit amount" value="" class="form-control"><br>
              <label for="libelle">Description</label><br>
              <input type="text" name="libelle" placeholder="Description" value="" class="form-control"><br>
              <label for="date">Deposit date</label><br>
              <input type="date" name="date_mes" class="form-control" placeholder="Deposit date" value=<?php echo date('Y-m-d');?>><br>
              <button type="Submit" name="Save" class="btn btn-danger">Save</button>
          </div>
        </form>
        <?php
        if(!empty($_POST)){
          extract($_POST);
          $valid = false;
          
          $numcompte = htmlspecialchars(trim($numcompte));
            $req = $statement->query('Select numcompte from user where numcompte = :numcompte', array('numcompte' => $numcompte));
          $req = $req->fetch();
          
          if(!empty($numcompte) && $req['numcompte']){
            $valid = true;
            $_SESSION['flash']['danger'] = "Ce compte n'existe pas! veuillez le creer";
            
              }
            } 
        ?>
      </div>
    </div>
  </body>
</html>
