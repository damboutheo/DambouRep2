<?php
require("database.php");
initMigration($pdo);
if (isset($_GET["show"]) && isset($_GET["numcompte"])) {
//$langue = $_GET["langue"];
  $numcompte= $_GET['numcompte'];
  try{
     $statement = $pdo->prepare(
      'SELECT * FROM depot WHERE numcompte = :numcompte ORDER BY date_mes DESC');
    $statement->execute(["numcompte" => $numcompte]);
    $results = $statement->fetchAll(PDO::FETCH_OBJ);
    //echo "Read from table users</br>";
  }catch (PDOException $e) {
      echo "<h4 style='color: red;'>".$e->getMessage(). "</h4>";
  }
}
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

		<title> Site avec bootstrap</title>
</head>
  <body>
     <nav class="navbar navbar-default" style="height: 100px">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="nomMenu">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="#"><img src="IMG/UBA-Logo.svg" alt="LOGO"></a>
				</div>
				<div class="collapse navbar-collapse" id="monMenu">
					<ul class="nav navbar-nav" style="margin-top: 30px">
						<li><a href="#">ACCUEIL</a></li>
						<li><a href="#">QUI SOMMES NOUS</a></li>
					</ul>
					<ul class="navbar-nav navbar-right" style="margin-top: 40px">
						<li><a href="#"><span class="glyphicon glyphicon-log-in"></span> ADMINISTRATEUR</a></li>
					</ul>
					<ul class="navbar-nav navbar-right" style="margin-top: 40px">
						<li><a href="#"><span class="glyphicon glyphicon-log-in"></span> ENTREE CLIENT</a></li>
					</ul>
				</div>
			</div>

        </nav>
        
            <?php foreach ($results as $message) { ?>
       <div class="container">
           <div class="heading">
               <h1><?php echo $message->id;?></h1><br>
           </div>
           <h1>Jour <?php echo $message->numcompte?></h1>
               <div class="row">
                    <div class="col-sm-3">
                        <div class="ref">
                            <div class="script"><h1>Reférence biblique</h1></div>
                           <div id="text"><P> <?php echo $message->montantdepot;?></p><br></div>
                            <style>.inter{
                                color: white;
                            }</style>
                            
                        </div>
                    </div>
                    <div class="col-sm-6">
                    <div class="thumbnail"><p><?php echo $message->libelle;?></p><br></div>
                    </div>
                    <div class="col-sm-3">
                        <div class="pensee">
                            <div class="pens"><h1>Pensée du jour</h1></div>
                            <?php echo $message->date_mes;?><br>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-3">
                        
                    </div>
                    <div class="col-sm-6">
                    
                    </div>
                    <div class="col-sm-3">
                    
                    </div>
                </div> 
            </div>
              
        
           
       <?php } ?>
    <!-- <div class="container">
        <div class="row">
            <form action="" method="GET" class="form-group">            
                <label for="name">Entrer votre numero de compte</label>
                <input type="text" placeholder="Numero de Compte"
                class="form-control" value="<?php if(isset($numcompte)) { echo $numcompte; }?>">
                <button type="submit" class="btn btn-primary">Valider</button>
            </form>
        </div>
    </div>
    <?php foreach ($results as $message) { ?>
        <?php echo $message->id;?> <br>
	     <?php echo $message->numcompte;?> <br>
         <?php echo $message->montantcompte;?><br>
         <?php echo $message->libelle;?><br>
         <?php echo $message->date_mes;?><br>
	<?php
			}
	?>
   -->
    </body>
</html>
