<?php
require("database.php");
//Create new depot

 if (isset($_GET["show"]) && isset($_GET["id"])) {
    $id = $_GET["id"];
    try{
      $statement = $pdo->prepare(
        'SELECT id,pseudo, mail, numcompte, nomprenom FROM user WHERE id = :id;'
      );
      $statement->execute(["id" => $id]);

      $results = $statement->fetchAll(PDO::FETCH_OBJ);
    //  echo "Read from table depot</br>";
    }catch (PDOException $e) {
        echo "<h4 style='color: red;'>".$e->getMessage(). "</h4>";
}
} else {
   echo "<script>location.href='client.php' </script>";
   die();
  }


 ?>
 <!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://fonts.googleapis.com/css?family=EB+Garamond&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/32597ef393.js" crossorigin="anonymous"></script>
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link href="https://fonts.googleapis.com/css2?family=Baloo+Bhaina+2:wght@500&display=swap" rel="stylesheet"> 
		<link href="style.css" rel="stylesheet" type="text/css" media="screen"/>
		<title></title>
</head>
  <body>
    <nav class="navbar navbar-inverse">
		  <div class="container-fluid">
		    
				<div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
				    	<a class="navbar-brand" href="index.html"><img src="IMG/UBA-Logo.svg" alt="LOGO" style="height: 35px"></a>	
					</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav" style="margin-top: 30px">
						<li style="font-size:20px"><a href="index.html"><i class="fas fa-home"></i></a></li>
            <li><a href="contact.html">CONTACT</a></li>
				</div>
		  </div>
		</nav>
    <a href="inscription.php">Create User</a>
    <!-- <a href="read.php?show=all">Show All Users</a> -->
    <div class="table-responsive">
        <table border="1" class="table table-striped table-dark">
            <tr>
                <th>id</th>
                <th>Username</th>
                <th>Email</th>
                <th>Account number</th>
                <th>Fullname</th>
                <th>Edit</th>
            </tr>

            <?php foreach ($results as $user) { ?>
            <tr>
                <td><?php echo $user->id;?></td>
                <td><?php echo $user->pseudo;?></td>
                <td><?php echo $user->mail;?></td>
                <td><?php echo $user->numcompte;?></td>
                <td><?php echo $user->nomprenom;?></td>
                <td><a href="updateclient.php?id=<?php echo $user->id;?>">Edit</a>
              </td>
            </tr><br>
            <?php } ?>
        </table>
     </div>  

  </body>
</html>
