<?php
session_start();
include_once('includes.php');
	// echo $_SESSION['id'];	
?>

<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="https://fonts.googleapis.com/css?family=EB+Garamond&display=swap" rel="stylesheet">
		<script src="https://kit.fontawesome.com/32597ef393.js" crossorigin="anonymous"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" media="screen" href="CSS/mains.css" />
		<link href="style.css" rel="stylesheet" type="text/css" media="screen"/>
		<title>Gospel of Christ Ministries</title>

	</head>
	
	<body>
	<div style="height:500px;background-color:transparent">
		<nav class="navbar navbar-default" style="height: 100px">
			<div class="container-fluid">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="nomMenu">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="#"><img src="IMG/UBA-Logo.svg" alt="LOGO"></a>
				</div>
				<div class="collapse navbar-collapse" id="monMenu">
					<ul class="nav navbar-nav" style="margin-top: 30px">
						<li><a href="#">HOME</a></li>
						<li><a href="#">CONTACT</a></li>
					</ul>
					<ul class="navbar-nav navbar-right" style="margin-top: 40px">
					<li style="font-size: 25px"><a href="login.php"> <i class="fas fa-users-cog"></i></a></li>
					</ul>
					<ul class="navbar-nav navbar-right" style="margin-top: 40px">
                        <li><a href="#"><span class="glyphicon glyphicon-log-in"></span><?php  if(!isset($_SESSION['id'])){echo "VOUS N'ETES PAS CONNECTES!";
                                                        }else{
                                                            echo $_SESSION['pseudo'];
                                                        
                                                        }
						       	                ?>
						       	
						    	        
                                
                            </a>
                        </li>
					</ul>
				</div>
			</div>

		</nav>
		<?php 
		    if(isset($_SESSION['flash'])){ 
		        foreach($_SESSION['flash'] as $type => $message): ?>
					<div id="alert" class="alert alert-<?= $type; ?> infoMessage"><a class="close">X</span></a>
						<?= $message; ?>
					</div>
		    
			<?php
			    endforeach;
			    unset($_SESSION['flash']);
			}
		?>    	
		
			<div class="container-fluid">
				<div class="row">
						
							<form action="consultation.php" method="GET">
								<div class="col-sm-4">
									<div><label for="numcompte">ACCOUNT NUMBER</label></div>
								</div>
								<div class="col-sm-4">
									<div><input class="input" type="text" name="numcompte" class="form-control" ></div>							    
								</div>
								<div class="col-sm-4">
										<a href="reads.php?show=one&numcompte={$numcompte}">
									
										<button class="button" type="Submit" name="Save" class="submit">SUBMIT</button>							
									</a>
								</div>
							</form>
				</div>     
        	</div>        

    </body>  
</html>
