<?php
function connectDB(){
  try{
    $database = new PDO('mysql:host=127.0.0.1;dbname=banque', 'root'.'');
    $database->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // echo "<h4 style='color: green;'>Connected to database</h4>";
    return $database;
  } catch(PDOException $e){
    echo "<h4 style='color: red;'>".$e->getMessage(). "</h4>";
  }
}
$pdo = connectDB();
function initMigration($pdo){
  try{
    $statement = $pdo->prepare(
       'CREATE TABLE IF NOT EXISTS users (
        id int NOT NULL AUTO_INCREMENT primary key,
        first_name varchar(255) NOT NULL,
        last_name varchar(255) NOT NULL,
        age int NOT NULL
      );,
 DROP TABLE IF EXISTS `depot`;
CREATE TABLE `depot` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `numcompte` varchar(255) NOT NULL,
  `montantdepot` float NOT NULL DEFAULT 0,
  `libelle` varchar(255),
  `date_mes` datetime NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4);,
DROP TABLE IF EXISTS `retrait`;
CREATE TABLE `retrait` (
  `IdRetrait` int(11) NOT NULL AUTO_INCREMENT,
  `NumCompte` varchar(16) NOT NULL,
  `DateRetrait` datetime DEFAULT NULL,
  `MontantRetrait` float NOT NULL DEFAULT 0,
  `Libelle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`IdRetrait`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4);,
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `Id` int(2) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(255) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `nomprenom` varchar(255) NOT NULL,
  `numcompte` varchar(255) NOT NULL,
  PRIMARY KEY (`Id`,`pseudo`,`email`(10),`numcompte`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4);,
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
);'
    );
    $statement->execute();
  }catch(PDOException $e){
    echo "<h4 style:'color: red;'>".$e->getMessage(). "</h4>";
  }
}
 ?>
