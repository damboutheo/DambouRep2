<?php
require("database.php");

// POST
//get
//PUT
//delete
//Handles post request
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_GET["id"]) && $_POST["_method"] == "PUT") {
  $numcompte = $_POST["numcompte"];
  $montantdepot = $_POST["montantdepot"];
  $libelle = $_POST["libelle"];
  $date_mes = $_POST["date_mes"];
  $id = $_GET["id"];
  try {
    $statement = $pdo->prepare(
      'UPDATE depot SET numcompte = :numcompte, montantdepot = :montantdepot, libelle = :libelle, date_mes = :date_mes WHERE id = :id'

    );
    $statement->execute(["numcompte" => $numcompte, "montantdepot" => $montantdepot, "libelle" => $libelle, "date_mes" => $date_mes, "id" => $id]);
    echo "Data updated";
  } catch (PDOException $e) {
      echo "<h4 style='color: red;'>".$e->getMessage(). "</h4>";
  }

}
//Handles get request
if (isset($_GET["id"])) {
  $id = $_GET["id"];
  try {
    $statement = $pdo->prepare(
      'SELECT * FROM depot WHERE id=:id;'
    );
    $statement->execute(["id" => $id]);
    $results = $statement->fetchAll(PDO::FETCH_OBJ);
  } catch (PDOException $e) {
      echo "<h4 style='color: red;'>".$e->getMessage(). "</h4>";
  }
}
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
 <head>
  <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="style.css" rel="stylesheet" type="text/css" media="screen"/>

		<title></title>
</head>
  <body>
  <nav class="navbar navbar-default">
		  <div class="container-fluid">
		    
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="index.html"><img src="IMG/UBA-Logo.svg" alt="LOGO" style="height: 50px"></a>	
					</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav" style="margin-top: 30px">
						<li><a href="index.html">HOME</a></li>
            <li><a href="contact.html">CONTACT</a></li>
						
					</ul>
						<ul class="navbar-nav navbar-right" style="margin-top: 40px">
						</ul>
				</div>
		  </div>
		</nav> 
    <div class="container-fluid jump">
        <div class="row">
          <form class="form-group" action="update.php?id=<?php echo $results[0]->id;?>" method="POST">
              <input type="hidden" name="_method" value="PUT" class="form-control">
                <label for="numcompte">Account number</label><br>
                <input type="text" name="numcompte" value="<?php echo
                $results[0]->numcompte;?>" class="form-control"><br>
                <label for="montantdepot">Deposit amount</label><br>
                <input type="text" name="montantdepot" value="<?php echo
                $results[0]->montantdepot;?>" class="form-control"><br>
                <label for="libelle">Description</label><br>
                <input type="text" name="libelle" value="<?php echo
                $results[0]->libelle;?>" class="form-control"><br>
                <input type="date" name="date_mes" value="<?php echo
                $results[0]->date_mes;?>" class="form-control"><br>
                <button type="Submit" name="Save" class="btn btn-info">Edit</button>

          </form>
          <a href="read.php?show=all">Retour</a>
        </div>
    </div>
  </body>
</html>
