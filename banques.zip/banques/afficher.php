
<!DOCTYPE html>
<html lang="en" dir="ltr">
 <head>
  <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://fonts.googleapis.com/css?family=EB+Garamond&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/32597ef393.js" crossorigin="anonymous"></script>
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="style.css" rel="stylesheet" type="text/css" media="screen"/>

		<title></title>
</head>
<body>
     <nav class="navbar navbar-inverse">
		  <div class="container-fluid">
		    
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="index.html"><img src="IMG/UBA-Logo.svg" alt="LOGO" style="height: 35px"></a>	
					</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav" style="margin-top: 30px">
						<li style="font-size:20px"><a href="index.html"><i class="fas fa-home"></i></a></li>
						<li><a href="#">CONTACT</a></li>
					</ul>
				</div>
		  </div>
		</nav>
		<h2 style="text-align:center">CONSULT YOUR ACCOUNT</h2>
  <div class="container-fluid jump">
      <div class="row">
          <form action="reads.php" class="form-group">
              <input type="text" placeholder="Entrer votre numero de compte" name="numcompte" class="form-control">
              <button type="submit" class="btn btn-danger">SUBMIT</button>
			   <a href="retrait.php"><input type="text" value="MAKE A WITHDRAWAL" class="btn btn-success"></a>
          </form>
      </div>
  </div>
</body>
</html>