<?php
require("database.php");
initMigration($pdo);
if ($_SERVER['REQUEST_METHOD'] == "GET") {
  try{
    $statement = $pdo->prepare(
      'SELECT * FROM depot;'
    );
    $statement->execute();

    $results = $statement->fetchAll(PDO::FETCH_OBJ);
    //echo "Read from table users</br>";
  }catch (PDOException $e) {
      echo "<h4 style='color: red;'>".$e->getMessage(). "</h4>";
  }
}
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
 <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://fonts.googleapis.com/css?family=EB+Garamond&display=swap" rel="stylesheet">
  <script src="https://kit.fontawesome.com/32597ef393.js" crossorigin="anonymous"></script>
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="style.css" rel="stylesheet" type="text/css" media="screen"/>

		<title></title>
</head>
   <nav class="navbar navbar-inverse">
		  <div class="container-fluid">
		    
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="index.html"><img src="IMG/UBA-Logo.svg" alt="LOGO" style="height: 35px"></a>	
					</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav" style="margin-top: 30px">
						<<li style="font-size:20px"><a href="index.html"><i class="fas fa-home"></i></a></li>
            <li><a href="contact.html">CONTACT</a></li>
						
					</ul>
						<ul class="navbar-nav navbar-right" style="margin-top: 40px">
						</ul>
				</div>
		  </div>
		</nav> 
  <body>
     <div class="container">
        <div class="row">
            <form action="" class="form-group">
                <div class="col-sm-4">
                     <a href="inscription.php"><input type="text" value="CREATE A CLIENT" class="btn btn-warning"/></a>                  
                     </div>
                <div class="col-sm-4">
                    <a href="create.php"><input type="text" value="MAKE A DEPOSIT" class="btn btn-info"/></a>
                </div>
                <div class="col-sm-4">
                    <a href="client.php"><input type="text" value="SHOW ALL USERS" class="btn btn-success"></a>
                </div>
            </form>
        </div>
    </div>       
     <table border="1" class="table table-striped table-dark">
        <tr>
            <th>Account Number</th>
            <th>Deposit amount ($)</th>
            <th>Description</th>
            <th>Deposit date</th>
            <th>Edit</th>
        </tr>

        <?php foreach ($results as $user) { ?>
          <tr>
              <td><?php echo $user->numcompte;?></td>
              <td><?php echo $user->montantdepot;?></td>
              <td><?php echo $user->libelle;?></td>
              <td><?php echo $user->date_mes;?></td>
              <td><a href="update.php?id=<?php echo $user->id;?>">Edit</a>
              </td>
          </tr><br>
          <?php } ?>
    </table>
  </body>
</html>
