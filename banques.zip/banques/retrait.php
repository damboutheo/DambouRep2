
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://fonts.googleapis.com/css?family=EB+Garamond&display=swap" rel="stylesheet">
  <script src="https://kit.fontawesome.com/32597ef393.js" crossorigin="anonymous"></script>
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link href="style.css" rel="stylesheet" type="text/css" media="screen"/>

		<title></title>
</head>
  <body>
  <nav class="navbar navbar-inverse navbar-fixed">
		  <div class="container-fluid">
		    
				<div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
				    	<a class="navbar-brand" href="index.html"><img src="IMG/UBA-Logo.svg" alt="LOGO" style="height: 35px"></a>	
					</div>
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" >
					<ul class="nav navbar-nav" style="margin-top: 30px">
						<li style="font-size:20px"><a href="index.html"><i class="fas fa-home"></i></a></li>
            <li><a href="contact.html">CONTACT</a></li>
					</ul>
					<ul class="navbar-nav navbar-right" style="margin-top: 40px">
						<li style="font-size: 25px"><a href="login.php"> <i class="fas fa-users-cog"></i></a></li>
					</ul>
					<!--<ul class="navbar-nav navbar-right" style="margin-top: 40px">
						<li><a href="inscription.php"><span class="glyphicon glyphicon-log-in"></span> CREER UN CLIENT</a></li>
					</ul>-->
				</div>
		  </div>
		</nav>
    <h1 style="text-align:center">MAKE A WITHDRAWAL</h1>
    <div class="container-fluid">
      <div class="row">
        <form class="creating" action="retrait.php" method="POST">
          <div class="form-group">
              <div class="col-sm-4">
                  <label for="nombanque">Receiving Bank</label><br>
                  <input type="text" name="libelle" placeholder="Receiving bank" value="" tabindex="1" class="form-control"><br>
                  <label for="codeswitch">Swift code</label><br>
                  <input type="text" name="codeswitch" placeholder="Swift code" value="" tabindex="2" class="form-control"><br>
                  
              </div>
              <div class="col-sm-4">
                   <label for="numcompte">Account number</label><br>
                  <input type="text" name="numcompte" placeholder="Account number" value="" tabindex="3" class="form-control"><br>
                  <label for="montantdepot">Amount</label><br>
                  <input type="text" name="montantdepot" placeholder="Deposit amount" value="" tabindex="4" class="form-control"><br>
              </div>
              <div class="col-sm-4">  
                  <label for="codeswitch">code</label><br>
                  <input type="text" name="codeswitch" placeholder="code" value="" tabindex="5" class="form-control"><br>  
                  <label for="date">Withdrawal date</label><br>
                  <input type="date" name="date_mes" class="form-control" placeholder="Deposit date" tabindex="6" value=<?php echo date('Y-m-d');?>><br>
                  <button type="Submit" name="Save" tabindex="7" class="btn btn-danger" onclick="myFunction()">Save</button>
                  <p id="demo"></p>

                  <script>
                      function myFunction() {
                        document.getElementById("demo").innerHTML = "You can not proceed to a withdrawal, contact your web account manager";
                      }
                  </script>
              </div>
          </div>
        </form>
        <!-- <?php
        if(!empty($_POST)){
          extract($_POST);
          $valid = false;
          
          $numcompte = htmlspecialchars(trim($numcompte));
            $req = $statement->query('Select numcompte from user where numcompte = :numcompte', array('numcompte' => $numcompte));
          $req = $req->fetch();
          
          if(!empty($numcompte) && $req['numcompte']){
            $valid = true;
            $_SESSION['flash']['danger'] = "Ce compte n'existe pas! veuillez le creer";
            
              }
            } 
        ?> -->
      </div>
    </div>
  </body>
</html>
